# Urblaux Studio - AI Web Builder Platform

## Descripcion General
**Urblaux Studio** es una plataforma de construccion de proyectos digitales potenciada por IA, disenada en **Material 3 Expressive de Google**. Permite crear webs, apps, juegos, sistemas operativos, motores de IA y mucho mas usando multiples agentes de IA coordinados.

## URLs
- **Sandbox**: https://3000-i8czy2i9ozfr62zfvyb6e-2e77fc33.sandbox.novita.ai
- **API Health**: /api/health

## Caracteristicas Implementadas

### Core Platform
- **Material 3 Expressive UI**: Interfaz completa con BeerCSS, animaciones spring, tipografia Google Sans, color tokens dinamicos
- **Sistema de Autenticacion**: Registro, login, sesiones con tokens, perfiles de usuario
- **Base de Datos D1**: SQLite distribuida con 9 tablas (users, sessions, projects, messages, agent_activity, sources, automations, memories)
- **Multi-Agent System**: 29 proveedores de IA con 59+ modelos coordinados

### Chats (3 tipos)
1. **Chat General**: Describe tu idea, sube archivos, audio, imagenes. La IA hace preguntas inteligentes para concretar. Conectado a todas las funcionalidades
2. **Chat de Diseno (Stitch)**: Potenciado por Stitch de Google, enfocado en UI/UX, colores, tipografias, layouts, animaciones Material 3
3. **Chat de Automatizacion**: Gestiona automatizaciones tipo n8n + Mission Control + Twin

### Sistema de Agentes
- **Director**: Orquesta el proceso completo (Gemini)
- **Buscador**: Busca informacion online y en fuentes (Tavily + Cohere)
- **Pensador**: Logica, arquitectura, planificacion (SambaNova, Mistral)
- **Programador**: Escribe y refactoriza codigo (Codestral, GPT-4.1)
- **Verificador**: Tests, deteccion de errores (Cerebras)
- **Disenador**: UI/UX con Stitch (Gemini + Stability AI)
- **Automatizador**: Crea y gestiona automatizaciones

### Proveedores de IA Verificados (29)
| Proveedor | Modelos | Especialidad |
|-----------|---------|-------------|
| Google Gemini | gemini-2.5-flash/pro | Director, Thinker |
| OpenRouter | 351+ modelos | Multi-provider |
| Mistral AI | mistral-large, codestral | Code, Thinking |
| SambaNova | DeepSeek-R1/V3, Llama-4 | Fast inference |
| Cerebras | llama3.1-8b, qwen-3 | Ultra-fast |
| Novita AI | 94 modelos | Image + Text |
| Cohere | command-r-plus | Search, Rerank |
| NVIDIA | 189 modelos | Enterprise AI |
| xAI | grok-3 | Search, Thinking |
| OpenAI | gpt-4.1, dall-e-3, whisper | Multimodal |
| Stability AI | SDXL | Image generation |
| ElevenLabs | multilingual_v2 | Audio/TTS |
| Deepgram | nova-3 | Transcription |
| Suno | v4 | Music generation |
| Runway | gen-3-alpha | Video generation |
| Replicate | flux | Image generation |
| Fireworks AI | llama-3.3-70b | Fast inference |
| Pollinations | flux | Free image gen |
| Hugging Face | Llama-3.3 | Open models |
| Tavily | search API | Web search |
| Pinecone | serverless | Vector DB |
| Eden AI | multi-provider | API aggregator |
| Together AI | Llama, DeepSeek | Fast inference |
| SiliconFlow | deepseek-v3, qwen | Chinese models |
| Kimi (Moonshot) | moonshot-v1 | Long context |
| GLM (Zhipu) | glm-4 | Chinese NLP |
| Vercel | deploy API | Deployment |
| Notion | API v1 | Knowledge base |
| Supabase | postgres, auth | Database |

### Fuentes (NotebookLM Style)
- Agregar URLs, texto, archivos
- Busqueda automatica de fuentes relevantes via Tavily
- Las fuentes alimentan el contexto de los agentes

### Pomelli (Google Labs Style)
- Business DNA analysis
- Generacion de campanas de marketing
- Contenido para redes sociales
- Logos y guia de estilo
- Photoshoots con IA

### Automatizacion (Mission Control + Twin + n8n)
- Error Checker automatico
- Mejora continua via busqueda web
- SEO y Analytics automatizados
- Chat para gestionar automatizaciones
- Flujos visuales y logs

### Publicacion
- Vercel (deploy instantaneo)
- GitHub Pages
- Cloudflare Pages
- Descarga como ZIP
- Dominio personalizado

### Sistema de Pagos para Usuarios
- Generacion de codigo para Stripe, PayPal, MercadoPago, Crypto
- El usuario recibe su dinero directamente (nosotros no tocamos nada)
- Inspirado en Shopify

### Urblaux Agent
- Super-agente que combina TODOS los modelos de IA
- Exportable como API key
- Capacidades: text, code, image, audio, music, video, search, vector DB

### Memoria y Aprendizaje
- Memorias persistentes por usuario
- La IA aprende de las preferencias del usuario
- Auto-deteccion de patrones para recordar

### Funcionalidades de los Chats
- Busqueda web en tiempo real (Tavily)
- Subida de archivos (imagenes, audio, video, documentos)
- Grabacion de audio
- Exportar/importar en cualquier formato
- Markdown + codigo resaltado
- Ver actividad de agentes en tiempo real

## Estructura del Proyecto
```
webapp/
  src/
    index.tsx          - App entry point (Hono + routes)
    lib/
      renderer.ts      - Material 3 Expressive HTML renderer
      utils.ts         - AI calls, auth, orchestration
    routes/
      auth.ts          - Registration, login, profile
      projects.ts      - CRUD projects
      chat.ts          - Multi-agent chat with AI
      agents.ts        - Agent registry and activity
      automations.ts   - Automation management
      sources.ts       - NotebookLM-style sources
      design.ts        - Stitch design chat
      pomelli.ts       - Brand content generation
      memory.ts        - User memory management
      search.ts        - Web + semantic search
      publish.ts       - Multi-platform publishing
      urblaux.ts       - Unified super-agent API
      payments.ts      - Payment system generator
  public/
    static/
      js/
        app.js         - Full frontend application (~67KB)
  migrations/
    0001_initial_schema.sql - D1 database schema
  seed.sql             - Demo data
  ecosystem.config.cjs - PM2 config
  wrangler.jsonc       - Cloudflare config
  package.json
  tsconfig.json
  vite.config.ts
```

## Arquitectura de Datos
- **Database**: Cloudflare D1 (SQLite distribuida)
- **9 Tablas**: users, sessions, projects, messages, agent_activity, sources, automations, memories
- **Auth**: Token-based con sesiones persistentes
- **AI Orchestration**: Multi-provider con fallback automatico

## API Endpoints
| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| GET | /api/health | Health check |
| POST | /api/auth/register | Registro de usuario |
| POST | /api/auth/login | Inicio de sesion |
| GET | /api/auth/me | Perfil del usuario |
| PUT | /api/auth/profile | Actualizar perfil |
| PUT | /api/auth/skills | Guardar skills personalizadas |
| GET | /api/projects | Listar proyectos |
| POST | /api/projects | Crear proyecto |
| GET | /api/projects/:id | Obtener proyecto |
| PUT | /api/projects/:id | Actualizar proyecto |
| DELETE | /api/projects/:id | Eliminar proyecto |
| POST | /api/chat/message | Enviar mensaje (multi-agent) |
| GET | /api/chat/history/:pid/:type | Historial de chat |
| GET | /api/agents | Listar todos los agentes |
| GET | /api/agents/activity/:pid | Actividad de agentes |
| GET | /api/automations | Listar automatizaciones |
| POST | /api/automations | Crear automatizacion |
| PUT | /api/automations/:id | Actualizar automatizacion |
| DELETE | /api/automations/:id | Eliminar automatizacion |
| GET | /api/sources/:pid | Listar fuentes |
| POST | /api/sources | Agregar fuente |
| POST | /api/sources/auto-search | Busqueda automatica |
| DELETE | /api/sources/:id | Eliminar fuente |
| POST | /api/design/message | Chat de diseno (Stitch) |
| POST | /api/pomelli/generate | Generar contenido de marca |
| GET | /api/pomelli/brand/:pid | Analisis de marca |
| GET | /api/memory | Obtener memorias |
| POST | /api/memory | Agregar memoria |
| DELETE | /api/memory/:id | Eliminar memoria |
| POST | /api/search/web | Busqueda web (Tavily) |
| POST | /api/search/semantic | Busqueda semantica (Cohere) |
| POST | /api/publish | Publicar proyecto |
| POST | /api/urblaux/chat | Urblaux Agent chat |
| GET | /api/urblaux/export | Exportar como API key |
| GET | /api/urblaux/models | Listar todos los modelos |
| POST | /api/payments/generate | Generar sistema de pagos |
| GET | /api/payments/providers | Proveedores de pago |

## Guia de Usuario
1. **Registrate** con email y contrasena
2. **Crea un proyecto** (web, app, juego, S.O., IA, tienda)
3. **Describe tu idea** en el Chat General - la IA te hara preguntas
4. **Sube fuentes** (URLs, archivos, imagenes) para dar contexto
5. **Observa los agentes** trabajando coordinados en tu proyecto
6. **Ajusta el diseno** con el Chat de Diseno (Stitch)
7. **Configura automatizaciones** para mejorar tu creacion continuamente
8. **Usa Pomelli** para contenido de marca
9. **Publica** en Vercel, GitHub Pages, Cloudflare o descarga

## Repositorios Integrados
- beercss/beercss - Material Design 3 framework
- meticha/material-3-expressive-catalog - M3 Expressive catalog
- VoltAgent/awesome-agent-skills - 1060+ agent skills
- sickn33/antigravity-awesome-skills - 12742+ skills
- ComposioHQ/awesome-claude-skills - Claude skills
- obra/superpowers - AI superpowers
- affaan-m/everything-claude-code - Claude Code skills
- nextlevelbuilder/ui-ux-pro-max-skill - UI/UX skills
- iOfficeAI/AionUi - UI components
- ruvnet/ruflo - Agent workflows
- thedotmack/claude-mem - Memory management
- Kargatharaakash/stitch-mcp - Stitch MCP server

## Tech Stack
- **Backend**: Hono (TypeScript) on Cloudflare Workers
- **Frontend**: Vanilla JS + BeerCSS (Material 3 Expressive)
- **Database**: Cloudflare D1 (SQLite)
- **AI**: 29 providers, 59+ models
- **Search**: Tavily API
- **Design**: Stitch + Stability AI
- **Deployment**: Cloudflare Pages

## Mejoras Futuras
- [ ] WebSocket para streaming de respuestas IA
- [ ] Editor de codigo en linea con Monaco Editor
- [ ] Preview en tiempo real con hot-reload
- [ ] Exportar proyectos como apps nativas (APK/IPA)
- [ ] Marketplace de templates y skills
- [ ] Colaboracion en tiempo real multi-usuario
- [ ] Historial de versiones con git
- [ ] Integracion directa con GitHub/GitLab
- [ ] Dashboard de analytics
- [ ] Sistema de plugins

## Deployment
- **Platform**: Cloudflare Pages
- **Status**: Active (Development)
- **Last Updated**: 2026-04-07
