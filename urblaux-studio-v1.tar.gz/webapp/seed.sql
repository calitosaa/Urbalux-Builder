-- Seed data for Urblaux Studio
-- Demo user (password: demo1234)
INSERT OR IGNORE INTO users (id, email, username, display_name, password_hash, plan) 
VALUES ('demo-user-001', 'demo@urblaux.studio', 'demo', 'Demo User', 'a3f2b8c1d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1', 'free');
