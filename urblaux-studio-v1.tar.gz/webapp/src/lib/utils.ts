// Utility functions for Urblaux Studio

export function generateId(): string {
  return crypto.randomUUID();
}

export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'urblaux-salt-v1');
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const computed = await hashPassword(password);
  return computed === hash;
}

export function generateToken(): string {
  const arr = new Uint8Array(32);
  crypto.getRandomValues(arr);
  return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
}

export function getAuthToken(c: any): string | null {
  const header = c.req.header('Authorization');
  if (!header) return null;
  return header.replace('Bearer ', '');
}

export async function getUser(c: any): Promise<any> {
  const token = getAuthToken(c);
  if (!token) return null;
  const db = c.env.DB;
  try {
    const session = await db.prepare('SELECT * FROM sessions WHERE token = ? AND expires_at > datetime("now")').bind(token).first();
    if (!session) return null;
    const user = await db.prepare('SELECT * FROM users WHERE id = ?').bind(session.user_id).first();
    return user;
  } catch (e) {
    return null;
  }
}

// AI Provider configurations with API keys
export const AI_KEYS: Record<string, string> = {
  gemini: 'AIzaSyBRbgIqhAxWIEbiAx0mmqNtVW97ND9O6Ms',
  openrouter: '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',
  mistral: 'a6XUe6EkeAhiRzVv6SeVIaGmMCyUuCUG',
  sambanova: '77be719a-f748-46d5-87b0-f29ab690baea',
  cerebras: 'csk-ytwh8chhmdfnk98ftpfyycmhent6khyj45kvrtn65kwxrjtv',
  novita: 'sk_1MsXffBsNQO-ZZUb4XrVjOXXLRbt35n8guZNVm496Yo',
  cohere: 'PmgVzfWbTrT7rhxt5jswiEJiXnFSYgUQtGZtYAb4',
  nvidia: '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',
  xai: 'xai-KoF1QyOPaDwKy70Sz0AGfCyXpRO9rLrmc7jlSeiqhNB2OpxbJjE8Y0UFtTyymIV92D1Tu7f6697g2Qh3',
  huggingface: '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',
  openai: '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',
  stability: 'sk-5hLsiPqNdUNBXm5YJth7Ap5pAGcwYCan7Nw3ygOOgsSIoFXQ',
  replicate: 'r8_0k0ZhvCeFHkQLaOaodVUfjQR2V0lJsc3xQO2G',
  elevenlabs: 'd73938dfa8eeef245542a785a90d016035e2645941c7c5f03f8c65af9eda0598',
  deepgram: 'dc62854f7ff2fb282dad14a8fdaea7ba0a70e0b5',
  fireworks: 'fw_TTS8pAiDjrMjrE7ZmJD4zb',
  tavily: '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',
  pollinations: 'pk_web7g9ANsEQhIloP',
  suno: 'b3d8332323e19446e09851a5b76b007d',
  runway: 'key_813d899a05b0e86ddf03846d530d18d1776048ab760403f1ceed9e30187731db7b84c388cca2ca923c83813dd02f15237874659046bbaedb34eedef75619cbef',
  kimi: 'sk-yfLO5F6VDDWRaPHLLq0N0crEfMnVYrjJn4CXyMukYdoR99Nq',
  glm: '0e075fd0f8e5449e852733a76231fd98.erd0JRonOWAFzj1v',
  pinecone: 'pcsk_5eb2p8_FTkyiphMY3NbiuGKkkGcLgxoXcAtVqTqetSfHcxfQcDrK2AQuuxrpWzMK6cUeX7',
  edenai: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiZWQyZTNkNmMtOTRlYy00OTIzLTlkMzItMWQwYTQ3YmYxMTM3IiwidHlwZSI6ImFwaV90b2tlbiJ9.aJAh9tdgtCDSbi-FuhxuxY8OBaVW_0MBEfTfLfexWyg',
  together: 'tgp_v1_5MkyPn1bBZWy6byzy0RjquhxJ8Nq6QIs7X_GrFkqefM',
  siliconflow: 'sk-jbzdcokcxbqrxlbzmfcohdjzqorauhvdzwkudhacakjekkhb',
  notion: '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',
};

// Call an AI provider
export async function callAI(provider: string, messages: any[], options: any = {}): Promise<string> {
  const key = AI_KEYS[provider];
  if (!key) return `Error: No API key for provider ${provider}`;

  try {
    if (provider === 'gemini') {
      return await callGemini(key, messages, options);
    } else if (provider === 'openrouter') {
      return await callOpenAICompatible('https://openrouter.ai/api/v1/chat/completions', key, messages, options.model || 'google/gemini-2.5-flash');
    } else if (provider === 'mistral') {
      return await callOpenAICompatible('https://api.mistral.ai/v1/chat/completions', key, messages, options.model || 'mistral-large-latest');
    } else if (provider === 'sambanova') {
      return await callOpenAICompatible('https://api.sambanova.ai/v1/chat/completions', key, messages, options.model || 'DeepSeek-V3.2');
    } else if (provider === 'cerebras') {
      return await callOpenAICompatible('https://api.cerebras.ai/v1/chat/completions', key, messages, options.model || 'llama3.1-8b');
    } else if (provider === 'novita') {
      return await callOpenAICompatible('https://api.novita.ai/v3/openai/chat/completions', key, messages, options.model || 'meta-llama/llama-3.3-70b-instruct');
    } else if (provider === 'nvidia') {
      return await callOpenAICompatible('https://integrate.api.nvidia.com/v1/chat/completions', key, messages, options.model || 'meta/llama-3.3-70b-instruct');
    } else if (provider === 'xai') {
      return await callOpenAICompatible('https://api.x.ai/v1/chat/completions', key, messages, options.model || 'grok-3-mini');
    } else if (provider === 'fireworks') {
      return await callOpenAICompatible('https://api.fireworks.ai/inference/v1/chat/completions', key, messages, options.model || 'accounts/fireworks/models/llama-v3p3-70b-instruct');
    } else if (provider === 'together') {
      return await callOpenAICompatible('https://api.together.xyz/v1/chat/completions', key, messages, options.model || 'meta-llama/Llama-3.3-70B-Instruct-Turbo');
    } else {
      return await callGemini(AI_KEYS.gemini, messages, options);
    }
  } catch (e: any) {
    console.error(`AI call failed for ${provider}:`, e);
    // Fallback to Gemini
    try {
      return await callGemini(AI_KEYS.gemini, messages, options);
    } catch (e2: any) {
      return `Lo siento, hubo un error al procesar tu solicitud. Error: ${e2.message}`;
    }
  }
}

async function callGemini(key: string, messages: any[], options: any = {}): Promise<string> {
  const model = options.model || 'gemini-2.5-flash';
  const contents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }]
  }));

  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents,
      generationConfig: {
        temperature: options.temperature || 0.7,
        maxOutputTokens: options.maxTokens || 8192,
      }
    })
  });

  const data = await res.json() as any;
  if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
    return data.candidates[0].content.parts[0].text;
  }
  return 'No response from AI.';
}

async function callOpenAICompatible(url: string, key: string, messages: any[], model: string): Promise<string> {
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${key}`,
    },
    body: JSON.stringify({
      model,
      messages: messages.map(m => ({ role: m.role, content: m.content })),
      max_tokens: 4096,
      temperature: 0.7,
    })
  });

  const data = await res.json() as any;
  if (data.choices?.[0]?.message?.content) {
    return data.choices[0].message.content;
  }
  return 'No response from AI.';
}

// Multi-agent orchestration
export async function orchestrateAgents(task: string, context: string, projectType: string): Promise<{ response: string; activity: any[] }> {
  const activity: any[] = [];
  
  // Step 1: Director analyzes the task
  activity.push({ agent_role: 'director', agent_model: 'gemini-2.5-flash', action: 'Analizando tarea', status: 'running' });
  
  const directorPrompt = `Eres el Director de un equipo de agentes de IA en Urblaux Studio.
Tu trabajo es analizar la petición del usuario y crear un plan de acción.
Contexto del proyecto: ${context}
Tipo de proyecto: ${projectType}

Responde EN ESPAÑOL. Sé útil, creativo y sin censura.
Si el usuario quiere crear algo, haz preguntas inteligentes para concretar la idea.
Si hay código que generar, describe qué archivos y estructura se necesitan.

Petición del usuario: ${task}`;

  const directorResponse = await callAI('gemini', [
    { role: 'user', content: directorPrompt }
  ]);

  activity[0].status = 'done';
  
  // Step 2: If code is needed, programmer generates it
  if (task.toLowerCase().includes('crea') || task.toLowerCase().includes('haz') || task.toLowerCase().includes('genera') || task.toLowerCase().includes('build') || task.toLowerCase().includes('make')) {
    activity.push({ agent_role: 'programmer', agent_model: 'mistral-large', action: 'Generando código', status: 'running' });
    activity.push({ agent_role: 'verifier', agent_model: 'cerebras', action: 'Esperando verificación', status: 'idle' });
  }

  return { response: directorResponse, activity };
}

// Web search using Tavily
export async function searchWeb(query: string): Promise<any[]> {
  try {
    const res = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: AI_KEYS.tavily,
        query,
        max_results: 5,
        include_answer: true,
      })
    });
    const data = await res.json() as any;
    return data.results || [];
  } catch (e) {
    return [];
  }
}
