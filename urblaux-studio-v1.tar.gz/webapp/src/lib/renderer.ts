export function renderApp(): string {
  return `<!DOCTYPE html>
<html lang="es" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Urblaux Studio - AI Web Builder</title>
  <meta name="description" content="Build anything with AI. Webs, Apps, Games, OS and more.">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>⚡</text></svg>">
  <!-- Beer CSS - Material 3 Expressive -->
  <link href="https://cdn.jsdelivr.net/npm/beercss@4.0.20/dist/cdn/beer.min.css" rel="stylesheet">
  <script type="module" src="https://cdn.jsdelivr.net/npm/beercss@4.0.20/dist/cdn/beer.min.js"></script>
  <script type="module" src="https://cdn.jsdelivr.net/npm/material-dynamic-colors@1.1.2/dist/cdn/material-dynamic-colors.min.js"></script>
  <!-- Google Fonts - Material Symbols -->
  <link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500;700&family=Google+Sans+Text:wght@400;500;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Symbols+Outlined" rel="stylesheet">
  <!-- Marked for Markdown -->
  <script src="https://cdn.jsdelivr.net/npm/marked@12.0.0/marked.min.js"></script>
  <!-- Highlight.js for code -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/highlight.js@11.9.0/styles/github-dark.min.css">
  <script src="https://cdn.jsdelivr.net/npm/highlight.js@11.9.0/highlight.min.js"></script>
  <style>
    :root {
      --md-ref-typeface-brand: 'Google Sans', sans-serif;
      --md-ref-typeface-plain: 'Google Sans Text', sans-serif;
      --m3-spring-duration: 500ms;
      --m3-spring-bounce: 0.35;
    }
    * { font-family: var(--md-ref-typeface-plain); box-sizing: border-box; }
    h1,h2,h3,h4,h5,h6,.headline,.display,.title { font-family: var(--md-ref-typeface-brand); }
    body { margin: 0; overflow: hidden; height: 100vh; background: var(--surface); }
    
    /* M3 Expressive Spring Animations */
    @keyframes m3SpringIn { 
      0% { transform: scale(0.8) translateY(20px); opacity: 0; }
      60% { transform: scale(1.03) translateY(-3px); opacity: 1; }
      100% { transform: scale(1) translateY(0); opacity: 1; }
    }
    @keyframes m3FadeSlideUp {
      0% { transform: translateY(16px); opacity: 0; }
      100% { transform: translateY(0); opacity: 1; }
    }
    @keyframes m3Pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.6; }
    }
    @keyframes m3Ripple {
      0% { transform: scale(0); opacity: 0.5; }
      100% { transform: scale(4); opacity: 0; }
    }
    @keyframes agentThinking {
      0% { background-position: -200% 0; }
      100% { background-position: 200% 0; }
    }
    .m3-spring { animation: m3SpringIn var(--m3-spring-duration) cubic-bezier(0.34, 1.56, 0.64, 1); }
    .m3-fade-up { animation: m3FadeSlideUp 400ms cubic-bezier(0.2, 0, 0, 1) forwards; }
    .m3-stagger > * { opacity: 0; animation: m3FadeSlideUp 400ms cubic-bezier(0.2, 0, 0, 1) forwards; }
    .m3-stagger > *:nth-child(1) { animation-delay: 50ms; }
    .m3-stagger > *:nth-child(2) { animation-delay: 100ms; }
    .m3-stagger > *:nth-child(3) { animation-delay: 150ms; }
    .m3-stagger > *:nth-child(4) { animation-delay: 200ms; }
    .m3-stagger > *:nth-child(5) { animation-delay: 250ms; }
    .m3-stagger > *:nth-child(6) { animation-delay: 300ms; }
    
    /* Agent thinking gradient */
    .agent-thinking {
      background: linear-gradient(90deg, transparent, var(--primary-container), transparent);
      background-size: 200% 100%;
      animation: agentThinking 2s infinite;
    }
    
    /* Layout */
    #app-root { display: flex; height: 100vh; overflow: hidden; }
    
    /* Navigation Rail - M3 Expressive */
    .nav-rail {
      width: 80px; min-width: 80px; height: 100vh;
      background: var(--surface-container);
      display: flex; flex-direction: column; align-items: center;
      padding: 12px 0; gap: 4px; z-index: 10;
      border-right: 1px solid var(--outline-variant);
      transition: width 300ms cubic-bezier(0.2, 0, 0, 1);
    }
    .nav-rail .logo {
      width: 56px; height: 56px; border-radius: 16px;
      display: flex; align-items: center; justify-content: center;
      background: var(--primary); color: var(--on-primary);
      font-size: 24px; font-weight: 700; margin-bottom: 16px;
      cursor: pointer; transition: all 300ms cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .nav-rail .logo:hover { transform: scale(1.08); border-radius: 20px; }
    .nav-item {
      display: flex; flex-direction: column; align-items: center;
      gap: 4px; padding: 4px 0; cursor: pointer; width: 100%;
      text-decoration: none; color: var(--on-surface-variant);
      transition: all 200ms cubic-bezier(0.2, 0, 0, 1);
    }
    .nav-item .icon-container {
      width: 56px; height: 32px; border-radius: 16px;
      display: flex; align-items: center; justify-content: center;
      transition: all 300ms cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .nav-item:hover .icon-container { background: var(--surface-container-highest); }
    .nav-item.active .icon-container { 
      background: var(--secondary-container); color: var(--on-secondary-container);
    }
    .nav-item.active { color: var(--on-surface); font-weight: 500; }
    .nav-item .label { font-size: 12px; line-height: 1; }

    /* Main Content Area */
    .main-area { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
    .top-bar {
      height: 64px; min-height: 64px;
      background: var(--surface-container);
      display: flex; align-items: center; padding: 0 16px; gap: 12px;
      border-bottom: 1px solid var(--outline-variant);
    }
    .content-area { flex: 1; display: flex; overflow: hidden; }
    
    /* Panels */
    .panel-left { 
      width: 320px; min-width: 280px; max-width: 400px;
      background: var(--surface-container-low);
      border-right: 1px solid var(--outline-variant);
      display: flex; flex-direction: column; overflow: hidden;
      transition: width 300ms cubic-bezier(0.2, 0, 0, 1);
    }
    .panel-center { flex: 1; display: flex; flex-direction: column; overflow: hidden; min-width: 0; }
    .panel-right {
      width: 340px; min-width: 280px; max-width: 420px;
      background: var(--surface-container-low);
      border-left: 1px solid var(--outline-variant);
      display: flex; flex-direction: column; overflow: hidden;
      transition: width 300ms cubic-bezier(0.2, 0, 0, 1);
    }
    .panel-header {
      padding: 16px; display: flex; align-items: center; gap: 8px;
      border-bottom: 1px solid var(--outline-variant); min-height: 56px;
    }
    .panel-content { flex: 1; overflow-y: auto; padding: 8px; }
    
    /* Chat Styles */
    .chat-container { display: flex; flex-direction: column; height: 100%; }
    .chat-messages { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 12px; }
    .chat-input-area {
      padding: 12px 16px; border-top: 1px solid var(--outline-variant);
      display: flex; flex-direction: column; gap: 8px;
    }
    .chat-input-row { display: flex; gap: 8px; align-items: flex-end; }
    .chat-input {
      flex: 1; min-height: 44px; max-height: 160px; padding: 10px 16px;
      background: var(--surface-container-highest); border: 1px solid var(--outline-variant);
      border-radius: 24px; color: var(--on-surface); font-size: 14px;
      resize: none; outline: none; font-family: inherit;
      transition: border-color 200ms;
    }
    .chat-input:focus { border-color: var(--primary); }
    .chat-input::placeholder { color: var(--on-surface-variant); }
    
    .msg { display: flex; gap: 8px; max-width: 85%; }
    .msg.user { align-self: flex-end; flex-direction: row-reverse; }
    .msg.assistant { align-self: flex-start; }
    .msg-bubble {
      padding: 10px 16px; border-radius: 20px; font-size: 14px;
      line-height: 1.5; word-break: break-word;
    }
    .msg.user .msg-bubble { 
      background: var(--primary); color: var(--on-primary);
      border-bottom-right-radius: 4px;
    }
    .msg.assistant .msg-bubble {
      background: var(--surface-container-high); color: var(--on-surface);
      border-bottom-left-radius: 4px;
    }
    .msg-avatar {
      width: 32px; height: 32px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; flex-shrink: 0;
    }
    .msg.assistant .msg-avatar { background: var(--tertiary-container); color: var(--on-tertiary-container); }
    .msg.user .msg-avatar { background: var(--primary-container); color: var(--on-primary-container); }
    
    /* Agent Activity Panel */
    .agent-card {
      padding: 12px; border-radius: 16px; margin-bottom: 8px;
      background: var(--surface-container);
      border: 1px solid var(--outline-variant);
      transition: all 200ms cubic-bezier(0.2, 0, 0, 1);
    }
    .agent-card:hover { background: var(--surface-container-high); transform: translateY(-1px); }
    .agent-status { 
      display: inline-flex; align-items: center; gap: 4px;
      padding: 2px 8px; border-radius: 8px; font-size: 11px; font-weight: 500;
    }
    .agent-status.running { background: var(--tertiary-container); color: var(--on-tertiary-container); }
    .agent-status.idle { background: var(--surface-container-highest); color: var(--on-surface-variant); }
    .agent-status.error { background: var(--error-container); color: var(--on-error-container); }
    .agent-status.done { background: var(--primary-container); color: var(--on-primary-container); }
    
    /* Source Cards */
    .source-card {
      padding: 12px; border-radius: 12px;
      background: var(--surface-container);
      border: 1px solid var(--outline-variant);
      margin-bottom: 8px; cursor: pointer;
      transition: all 200ms cubic-bezier(0.2, 0, 0, 1);
    }
    .source-card:hover { background: var(--surface-container-high); }
    
    /* Preview Frame */
    .preview-frame {
      flex: 1; border: none; width: 100%; height: 100%;
      background: white; border-radius: 12px;
    }
    
    /* Tabs - M3 Expressive */
    .m3-tabs {
      display: flex; gap: 0; border-bottom: 1px solid var(--outline-variant);
      overflow-x: auto; min-height: 48px;
    }
    .m3-tab {
      padding: 0 16px; height: 48px; display: flex; align-items: center; justify-content: center;
      gap: 8px; font-size: 14px; font-weight: 500; cursor: pointer;
      color: var(--on-surface-variant); border-bottom: 3px solid transparent;
      white-space: nowrap; transition: all 200ms cubic-bezier(0.2, 0, 0, 1);
      background: none; border-top: none; border-left: none; border-right: none;
    }
    .m3-tab:hover { color: var(--on-surface); background: var(--surface-container-high); }
    .m3-tab.active { 
      color: var(--primary); border-bottom-color: var(--primary);
      font-weight: 600;
    }
    
    /* Chip */
    .m3-chip {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 12px; border-radius: 8px; font-size: 12px;
      background: var(--surface-container-high); color: var(--on-surface);
      border: 1px solid var(--outline-variant); cursor: pointer;
      transition: all 200ms;
    }
    .m3-chip:hover { background: var(--surface-container-highest); }
    .m3-chip.selected { background: var(--secondary-container); color: var(--on-secondary-container); border-color: transparent; }
    
    /* FAB */
    .m3-fab {
      position: fixed; bottom: 24px; right: 24px;
      width: 56px; height: 56px; border-radius: 16px;
      background: var(--primary-container); color: var(--on-primary-container);
      display: flex; align-items: center; justify-content: center;
      box-shadow: var(--elevation-3); cursor: pointer; border: none;
      transition: all 300ms cubic-bezier(0.34, 1.56, 0.64, 1); z-index: 100;
    }
    .m3-fab:hover { transform: scale(1.05); box-shadow: var(--elevation-4); }
    
    /* Cards */
    .m3-card {
      background: var(--surface-container); border-radius: 16px;
      padding: 16px; border: 1px solid var(--outline-variant);
      transition: all 200ms cubic-bezier(0.2, 0, 0, 1);
    }
    .m3-card:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.15); }
    
    /* Buttons */
    .m3-btn {
      display: inline-flex; align-items: center; justify-content: center; gap: 8px;
      padding: 0 24px; height: 40px; border-radius: 20px; font-size: 14px;
      font-weight: 500; cursor: pointer; border: none;
      transition: all 200ms cubic-bezier(0.2, 0, 0, 1);
      font-family: var(--md-ref-typeface-brand);
    }
    .m3-btn-filled { background: var(--primary); color: var(--on-primary); }
    .m3-btn-filled:hover { box-shadow: 0 1px 3px rgba(0,0,0,0.3); }
    .m3-btn-tonal { background: var(--secondary-container); color: var(--on-secondary-container); }
    .m3-btn-outlined { background: transparent; color: var(--primary); border: 1px solid var(--outline); }
    .m3-btn-text { background: transparent; color: var(--primary); }
    .m3-btn-icon {
      width: 40px; height: 40px; padding: 0; border-radius: 50%;
      background: transparent; color: var(--on-surface-variant);
      border: none; cursor: pointer; display: flex; align-items: center;
      justify-content: center; transition: all 200ms;
    }
    .m3-btn-icon:hover { background: var(--surface-container-highest); }
    
    /* Dialog / Modal */
    .m3-dialog-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,0.5);
      z-index: 1000; display: flex; align-items: center; justify-content: center;
      opacity: 0; pointer-events: none; transition: opacity 200ms;
    }
    .m3-dialog-overlay.open { opacity: 1; pointer-events: all; }
    .m3-dialog {
      background: var(--surface-container-high); border-radius: 28px;
      padding: 24px; min-width: 320px; max-width: 560px; width: 90%;
      max-height: 80vh; overflow-y: auto;
      transform: scale(0.9); transition: transform 300ms cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    .m3-dialog-overlay.open .m3-dialog { transform: scale(1); }
    
    /* Automation Cards */
    .auto-card {
      background: var(--surface-container); border-radius: 16px;
      padding: 16px; margin-bottom: 12px;
      border: 1px solid var(--outline-variant);
      transition: all 200ms;
    }
    .auto-card.active { border-color: var(--primary); }
    .auto-node {
      display: flex; align-items: center; gap: 8px;
      padding: 8px 12px; border-radius: 12px;
      background: var(--surface-container-high);
      margin: 4px 0; font-size: 13px;
    }
    
    /* Scrollbar */
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: var(--outline-variant); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: var(--outline); }
    
    /* Loading */
    .skeleton {
      background: linear-gradient(90deg, var(--surface-container) 25%, var(--surface-container-high) 50%, var(--surface-container) 75%);
      background-size: 200% 100%;
      animation: agentThinking 1.5s infinite;
      border-radius: 8px;
    }
    
    /* Auth Screen */
    .auth-screen {
      display: flex; align-items: center; justify-content: center;
      height: 100vh; background: var(--surface);
    }
    .auth-card {
      width: 420px; max-width: 95vw; padding: 40px;
      background: var(--surface-container); border-radius: 28px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    }
    .auth-input {
      width: 100%; padding: 14px 16px; border-radius: 12px;
      background: var(--surface-container-highest);
      border: 1px solid var(--outline-variant);
      color: var(--on-surface); font-size: 14px; outline: none;
      font-family: inherit; margin-bottom: 12px;
      transition: border-color 200ms;
    }
    .auth-input:focus { border-color: var(--primary); }
    .auth-input::placeholder { color: var(--on-surface-variant); }
    
    /* View transitions */
    .view { display: none; height: 100%; }
    .view.active { display: flex; flex-direction: column; }
    
    /* Responsive */
    @media (max-width: 1024px) {
      .panel-left, .panel-right { display: none; }
      .nav-rail { width: 60px; min-width: 60px; }
      .nav-item .label { display: none; }
    }
    @media (max-width: 768px) {
      .nav-rail { 
        position: fixed; bottom: 0; left: 0; right: 0;
        width: 100% !important; height: 64px; flex-direction: row;
        justify-content: space-around; border-right: none;
        border-top: 1px solid var(--outline-variant); z-index: 100;
      }
      .nav-rail .logo { display: none; }
      #app-root { flex-direction: column; }
      .main-area { padding-bottom: 64px; }
    }

    /* Code blocks */
    .msg-bubble pre { 
      background: var(--surface-container-lowest); padding: 12px;
      border-radius: 12px; overflow-x: auto; margin: 8px 0;
    }
    .msg-bubble code { font-family: 'JetBrains Mono', monospace; font-size: 13px; }

    /* File upload area */
    .upload-area {
      border: 2px dashed var(--outline-variant); border-radius: 16px;
      padding: 24px; text-align: center; cursor: pointer;
      transition: all 200ms;
    }
    .upload-area:hover { border-color: var(--primary); background: var(--surface-container); }
    .upload-area.dragover { border-color: var(--primary); background: var(--primary-container); }
  </style>
</head>
<body>
  <div id="app-root"></div>
  <script type="module" src="/static/js/app.js"></script>
</body>
</html>`
}
