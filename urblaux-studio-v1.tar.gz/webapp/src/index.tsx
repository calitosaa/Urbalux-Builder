import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { authRoutes } from './routes/auth'
import { projectRoutes } from './routes/projects'
import { chatRoutes } from './routes/chat'
import { agentRoutes } from './routes/agents'
import { automationRoutes } from './routes/automations'
import { sourceRoutes } from './routes/sources'
import { publishRoutes } from './routes/publish'
import { searchRoutes } from './routes/search'
import { designRoutes } from './routes/design'
import { pomelliRoutes } from './routes/pomelli'
import { memoryRoutes } from './routes/memory'
import { urblauxRoutes } from './routes/urblaux'
import { paymentRoutes } from './routes/payments'
import { renderApp } from './lib/renderer'

type Bindings = {
  DB: D1Database
}

const app = new Hono<{ Bindings: Bindings }>()

app.use('/api/*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}))

// API Routes
app.route('/api/auth', authRoutes)
app.route('/api/projects', projectRoutes)
app.route('/api/chat', chatRoutes)
app.route('/api/agents', agentRoutes)
app.route('/api/automations', automationRoutes)
app.route('/api/sources', sourceRoutes)
app.route('/api/publish', publishRoutes)
app.route('/api/search', searchRoutes)
app.route('/api/design', designRoutes)
app.route('/api/pomelli', pomelliRoutes)
app.route('/api/memory', memoryRoutes)
app.route('/api/urblaux', urblauxRoutes)
app.route('/api/payments', paymentRoutes)

// Health check
app.get('/api/health', (c) => c.json({ status: 'ok', version: '1.0.0', name: 'Urblaux Studio' }))

// Main app - serve the SPA
app.get('*', (c) => {
  return c.html(renderApp())
})

export default app
