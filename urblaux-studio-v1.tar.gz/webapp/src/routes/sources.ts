import { Hono } from 'hono'
import { generateId, getUser, searchWeb, callAI } from '../lib/utils'

type Bindings = { DB: D1Database }
export const sourceRoutes = new Hono<{ Bindings: Bindings }>()

// List sources
sourceRoutes.get('/:projectId', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const projectId = c.req.param('projectId')
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM sources WHERE project_id = ? ORDER BY created_at DESC')
      .bind(projectId).all()
    return c.json({ sources: results })
  } catch(e) {
    return c.json({ sources: [] })
  }
})

// Add source
sourceRoutes.post('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { title, type, url, content, project_id } = await c.req.json()
  const id = generateId()
  
  // If URL, try to fetch content
  let finalContent = content || ''
  if (type === 'url' && url) {
    try {
      const res = await fetch(url)
      const text = await res.text()
      finalContent = text.substring(0, 10000) // Limit
    } catch(e) { /* OK */ }
  }

  try {
    await c.env.DB.prepare('INSERT INTO sources (id, project_id, type, title, content, url) VALUES (?, ?, ?, ?, ?, ?)')
      .bind(id, project_id || 'default', type || 'text', title || url || 'Sin título', finalContent, url || '').run()
    return c.json({ source: { id, title: title || url, type, url, content: finalContent } })
  } catch(e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// Auto-search sources (NotebookLM style)
sourceRoutes.post('/auto-search', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { project_id } = await c.req.json()
  
  // Get project info
  let projectName = 'web project'
  try {
    const project = await c.env.DB.prepare('SELECT name, type, description FROM projects WHERE id = ?').bind(project_id).first() as any
    if (project) projectName = `${project.name} (${project.type}): ${project.description}`
  } catch(e) {}
  
  // Use Tavily to search for relevant sources
  const results = await searchWeb(`best practices resources for building ${projectName}`)
  const sources = results.slice(0, 5).map((r: any) => ({
    id: generateId(),
    title: r.title || 'Web source',
    type: 'url',
    url: r.url,
    content: r.content?.substring(0, 5000) || '',
    auto_added: 1,
  }))

  // Save to DB
  for (const s of sources) {
    try {
      await c.env.DB.prepare('INSERT INTO sources (id, project_id, type, title, content, url, auto_added) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .bind(s.id, project_id || 'default', s.type, s.title, s.content, s.url, 1).run()
    } catch(e) {}
  }

  return c.json({ sources })
})

// Delete source
sourceRoutes.delete('/:id', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const id = c.req.param('id')
  await c.env.DB.prepare('DELETE FROM sources WHERE id = ?').bind(id).run()
  return c.json({ success: true })
})
