import { Hono } from 'hono'
import { generateId, getUser } from '../lib/utils'

type Bindings = { DB: D1Database }
export const memoryRoutes = new Hono<{ Bindings: Bindings }>()

// Get memories
memoryRoutes.get('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM memories WHERE user_id = ? ORDER BY importance DESC, created_at DESC')
      .bind(user.id).all()
    return c.json({ memories: results || [] })
  } catch(e) {
    return c.json({ memories: [] })
  }
})

// Add memory
memoryRoutes.post('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { content, category, importance } = await c.req.json()
  const id = generateId()
  try {
    await c.env.DB.prepare('INSERT INTO memories (id, user_id, category, content, importance) VALUES (?, ?, ?, ?, ?)')
      .bind(id, user.id, category || 'general', content, importance || 0.5).run()
    return c.json({ memory: { id, content, category, importance } })
  } catch(e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// Delete memory
memoryRoutes.delete('/:id', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const id = c.req.param('id')
  await c.env.DB.prepare('DELETE FROM memories WHERE id = ? AND user_id = ?').bind(id, user.id).run()
  return c.json({ success: true })
})
