import { Hono } from 'hono'
import { getUser, callAI, generateId } from '../lib/utils'

type Bindings = { DB: D1Database }
export const pomelliRoutes = new Hono<{ Bindings: Bindings }>()

// Generate Pomelli content
pomelliRoutes.post('/generate', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { action, project_id } = await c.req.json()

  let projectInfo = ''
  try {
    const project = await c.env.DB.prepare('SELECT * FROM projects WHERE id = ?').bind(project_id).first() as any
    if (project) projectInfo = `Proyecto: ${project.name}, Tipo: ${project.type}, Descripción: ${project.description}`
  } catch(e) {}

  const prompts: Record<string, string> = {
    campaign: `Genera ideas de campaña de marketing para: ${projectInfo}. Incluye: concepto creativo, mensajes clave, público objetivo, canales recomendados, y calendario sugerido. Responde en español.`,
    social: `Crea contenido para redes sociales (Instagram, Twitter/X, TikTok, LinkedIn) para: ${projectInfo}. Genera 3 posts para cada red con hashtags y call-to-action. Responde en español.`,
    logo: `Describe 3 conceptos de logo y guía de estilo para: ${projectInfo}. Incluye: colores sugeridos (hex), tipografías, estilo visual, y significado del diseño. Responde en español.`,
    photoshoot: `Describe 5 ideas de fotos de producto/marca para: ${projectInfo}. Incluye: concepto, iluminación, escenario, props, y estilo de edición. Responde en español.`,
  }

  const prompt = prompts[action] || `Genera contenido de marca para: ${projectInfo}. Responde en español.`
  const response = await callAI('gemini', [{ role: 'user', content: prompt }])

  return c.json({ result: response, action })
})

// Get brand DNA analysis
pomelliRoutes.get('/brand/:projectId', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const projectId = c.req.param('projectId')
  
  try {
    const project = await c.env.DB.prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?').bind(projectId, user.id).first() as any
    if (!project) return c.json({ error: 'Not found' }, 404)

    const analysis = await callAI('gemini', [{
      role: 'user',
      content: `Analiza este proyecto y crea un "Business DNA" detallado. Proyecto: ${project.name}, Tipo: ${project.type}, Descripción: ${project.description}. 
      Incluye: identidad de marca, colores sugeridos, tipografía, tono de voz, público objetivo, propuesta de valor. Responde en JSON.`
    }])

    return c.json({ brand: analysis })
  } catch(e: any) {
    return c.json({ error: e.message }, 500)
  }
})
