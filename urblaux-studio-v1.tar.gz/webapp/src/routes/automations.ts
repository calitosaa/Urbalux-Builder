import { Hono } from 'hono'
import { generateId, getUser } from '../lib/utils'

type Bindings = { DB: D1Database }
export const automationRoutes = new Hono<{ Bindings: Bindings }>()

// List automations
automationRoutes.get('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM automations WHERE user_id = ? ORDER BY created_at DESC')
      .bind(user.id).all()
    return c.json({ automations: results })
  } catch(e) {
    return c.json({ automations: [] })
  }
})

// Create automation
automationRoutes.post('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { name, description, agents, project_id, instructions, schedule } = await c.req.json()
  const id = generateId()
  try {
    await c.env.DB.prepare('INSERT INTO automations (id, project_id, user_id, name, description, instructions, agents, schedule) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .bind(id, project_id || 'default', user.id, name, description || '', instructions || '', JSON.stringify(agents || []), JSON.stringify(schedule || {})).run()
    return c.json({ automation: { id, name, description, agents, status: 'paused' } })
  } catch(e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// Update automation
automationRoutes.put('/:id', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const id = c.req.param('id')
  const { status, instructions, agents, name } = await c.req.json()
  try {
    if (status) await c.env.DB.prepare('UPDATE automations SET status = ? WHERE id = ? AND user_id = ?').bind(status, id, user.id).run()
    if (instructions) await c.env.DB.prepare('UPDATE automations SET instructions = ? WHERE id = ? AND user_id = ?').bind(instructions, id, user.id).run()
    if (agents) await c.env.DB.prepare('UPDATE automations SET agents = ? WHERE id = ? AND user_id = ?').bind(JSON.stringify(agents), id, user.id).run()
    if (name) await c.env.DB.prepare('UPDATE automations SET name = ? WHERE id = ? AND user_id = ?').bind(name, id, user.id).run()
    return c.json({ success: true })
  } catch(e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// Delete automation
automationRoutes.delete('/:id', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const id = c.req.param('id')
  await c.env.DB.prepare('DELETE FROM automations WHERE id = ? AND user_id = ?').bind(id, user.id).run()
  return c.json({ success: true })
})
