import { Hono } from 'hono'
import { getUser, searchWeb, AI_KEYS } from '../lib/utils'

type Bindings = { DB: D1Database }
export const searchRoutes = new Hono<{ Bindings: Bindings }>()

// Real-time web search
searchRoutes.post('/web', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { query } = await c.req.json()
  if (!query) return c.json({ error: 'Query required' }, 400)

  const results = await searchWeb(query)
  return c.json({ results })
})

// Search with Cohere (semantic search)
searchRoutes.post('/semantic', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { query, documents } = await c.req.json()

  try {
    const res = await fetch('https://api.cohere.com/v2/rerank', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${AI_KEYS.cohere}`,
      },
      body: JSON.stringify({
        model: 'rerank-v3.5',
        query,
        documents: documents || [],
        top_n: 5,
      })
    })
    const data = await res.json()
    return c.json({ results: data })
  } catch(e: any) {
    return c.json({ error: e.message }, 500)
  }
})
