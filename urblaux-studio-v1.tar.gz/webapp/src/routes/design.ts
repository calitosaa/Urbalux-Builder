import { Hono } from 'hono'
import { getUser, callAI, generateId } from '../lib/utils'

type Bindings = { DB: D1Database }
export const designRoutes = new Hono<{ Bindings: Bindings }>()

// Design chat message (Stitch-powered)
designRoutes.post('/message', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { project_id, content } = await c.req.json()

  const systemPrompt = `Eres Stitch, el asistente de diseño UI/UX de Urblaux Studio.
Estás especializado en Material Design 3 Expressive de Google.
REGLAS:
- Responde EN ESPAÑOL
- Cuando el usuario pida cambios de diseño, genera código CSS/HTML concreto
- Usa color tokens de Material 3: --primary, --secondary, --tertiary, --surface, etc
- Sugiere animaciones con cubic-bezier(0.34, 1.56, 0.64, 1) para spring effects
- Recomienda tipografías Google Sans, Noto Sans, o Roboto
- Para layouts usa CSS Grid y Flexbox
- Mantén siempre la estética Material 3 Expressive: bordes redondeados (16-28px), elevaciones sutiles, colores vibrantes
- Si piden paletas de colores, sugiere usando el sistema de color M3 (primary, secondary, tertiary, error, neutral)
- Puedes generar componentes completos: cards, buttons, navigation, dialogs, chips, FABs`

  const response = await callAI('gemini', [
    { role: 'user', content: systemPrompt },
    { role: 'user', content: content }
  ])

  // Save message
  try {
    const msgId = generateId()
    await c.env.DB.prepare('INSERT INTO messages (id, project_id, user_id, chat_type, role, content) VALUES (?, ?, ?, ?, ?, ?)')
      .bind(msgId, project_id || 'default', user.id, 'design', 'user', content).run()
    const resMsgId = generateId()
    await c.env.DB.prepare('INSERT INTO messages (id, project_id, user_id, chat_type, role, content, agent_id) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .bind(resMsgId, project_id || 'default', user.id, 'design', 'assistant', response, 'stitch').run()
  } catch(e) {}

  return c.json({ response })
})
