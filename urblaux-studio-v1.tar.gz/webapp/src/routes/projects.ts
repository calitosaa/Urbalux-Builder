import { Hono } from 'hono'
import { generateId, getUser } from '../lib/utils'

type Bindings = { DB: D1Database }
export const projectRoutes = new Hono<{ Bindings: Bindings }>()

// List projects
projectRoutes.get('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { results } = await c.env.DB.prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC')
    .bind(user.id).all()
  return c.json({ projects: results })
})

// Get single project
projectRoutes.get('/:id', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const id = c.req.param('id')
  const project = await c.env.DB.prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?').bind(id, user.id).first()
  if (!project) return c.json({ error: 'Not found' }, 404)
  return c.json({ project })
})

// Create project
projectRoutes.post('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { name, description, type } = await c.req.json()
  if (!name) return c.json({ error: 'Name required' }, 400)
  const id = generateId()
  await c.env.DB.prepare(`INSERT INTO projects (id, user_id, name, description, type) VALUES (?, ?, ?, ?, ?)`)
    .bind(id, user.id, name, description || '', type || 'web').run()
  const project = await c.env.DB.prepare('SELECT * FROM projects WHERE id = ?').bind(id).first()
  return c.json({ project })
})

// Update project
projectRoutes.put('/:id', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const id = c.req.param('id')
  const body = await c.req.json()
  const sets: string[] = []
  const vals: any[] = []
  for (const [k, v] of Object.entries(body)) {
    if (['name', 'description', 'status', 'code', 'files', 'settings', 'preview_url', 'published_url', 'sources', 'automation_config', 'pomelli_config', 'design_config', 'payment_config'].includes(k)) {
      sets.push(`${k} = ?`)
      vals.push(typeof v === 'object' ? JSON.stringify(v) : v)
    }
  }
  if (sets.length === 0) return c.json({ error: 'Nothing to update' }, 400)
  sets.push('updated_at = datetime("now")')
  vals.push(id, user.id)
  await c.env.DB.prepare(`UPDATE projects SET ${sets.join(', ')} WHERE id = ? AND user_id = ?`).bind(...vals).run()
  return c.json({ success: true })
})

// Delete project
projectRoutes.delete('/:id', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const id = c.req.param('id')
  await c.env.DB.prepare('DELETE FROM projects WHERE id = ? AND user_id = ?').bind(id, user.id).run()
  return c.json({ success: true })
})
