import { Hono } from 'hono'
import { getUser, callAI, generateId } from '../lib/utils'

type Bindings = { DB: D1Database }
export const paymentRoutes = new Hono<{ Bindings: Bindings }>()

// Generate payment system code for user's project
paymentRoutes.post('/generate', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { project_id, payment_type, config } = await c.req.json()

  const prompt = `Genera el código completo para integrar un sistema de pago ${payment_type || 'Stripe'} en un proyecto web.
Configuración: ${JSON.stringify(config || {})}
El sistema debe:
- Permitir al usuario (creador de la web) recibir pagos
- Nosotros (Urblaux Studio) NO tocamos ni vemos el dinero del usuario
- Ser seguro y cumplir con estándares PCI
- Incluir: checkout, webhooks, gestión de productos, historial de transacciones
- Inspirarse en Shopify pero más simple
Genera código HTML + JavaScript + instrucciones claras. Responde en español.`

  const response = await callAI('gemini', [{ role: 'user', content: prompt }])

  // Save payment config to project
  try {
    await c.env.DB.prepare('UPDATE projects SET payment_config = ?, updated_at = datetime("now") WHERE id = ? AND user_id = ?')
      .bind(JSON.stringify({ payment_type, config, generated: true }), project_id, user.id).run()
  } catch(e) {}

  return c.json({ code: response })
})

// Get supported payment providers
paymentRoutes.get('/providers', async (c) => {
  return c.json({
    providers: [
      { id: 'stripe', name: 'Stripe', desc: 'Pagos con tarjeta, wallets, subscripciones', icon: '💳' },
      { id: 'paypal', name: 'PayPal', desc: 'Pagos con PayPal, Venmo', icon: '🅿️' },
      { id: 'mercadopago', name: 'Mercado Pago', desc: 'Popular en Latinoamérica', icon: '🤝' },
      { id: 'crypto', name: 'Crypto', desc: 'Bitcoin, Ethereum, USDT', icon: '₿' },
      { id: 'custom', name: 'Personalizado', desc: 'Integración a medida', icon: '⚡' },
    ]
  })
})
