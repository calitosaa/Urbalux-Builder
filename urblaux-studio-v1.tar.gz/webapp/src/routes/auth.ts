import { Hono } from 'hono'
import { generateId, hashPassword, verifyPassword, generateToken, getUser } from '../lib/utils'

type Bindings = { DB: D1Database }
export const authRoutes = new Hono<{ Bindings: Bindings }>()

// Register
authRoutes.post('/register', async (c) => {
  const { username, email, password, display_name } = await c.req.json()
  if (!username || !email || !password) return c.json({ error: 'Missing fields' }, 400)
  
  const db = c.env.DB
  try {
    // Check existing
    const existing = await db.prepare('SELECT id FROM users WHERE email = ? OR username = ?').bind(email, username).first()
    if (existing) return c.json({ error: 'User already exists' }, 409)
    
    const id = generateId()
    const password_hash = await hashPassword(password)
    const token = generateToken()
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    
    await db.prepare(`INSERT INTO users (id, email, username, display_name, password_hash) VALUES (?, ?, ?, ?, ?)`)
      .bind(id, email, username, display_name || username, password_hash).run()
    
    const sessionId = generateId()
    await db.prepare('INSERT INTO sessions (id, user_id, token, expires_at) VALUES (?, ?, ?, ?)')
      .bind(sessionId, id, token, expiresAt).run()
    
    return c.json({ 
      token, 
      user: { id, email, username, display_name: display_name || username }
    })
  } catch (e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// Login
authRoutes.post('/login', async (c) => {
  const { email, password } = await c.req.json()
  if (!email || !password) return c.json({ error: 'Missing fields' }, 400)
  
  const db = c.env.DB
  try {
    const user = await db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first() as any
    if (!user) return c.json({ error: 'User not found' }, 404)
    
    const valid = await verifyPassword(password, user.password_hash)
    if (!valid) return c.json({ error: 'Invalid password' }, 401)
    
    const token = generateToken()
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    const sessionId = generateId()
    
    await db.prepare('INSERT INTO sessions (id, user_id, token, expires_at) VALUES (?, ?, ?, ?)')
      .bind(sessionId, user.id, token, expiresAt).run()
    
    await db.prepare('UPDATE users SET last_login = datetime("now") WHERE id = ?').bind(user.id).run()
    
    return c.json({
      token,
      user: { id: user.id, email: user.email, username: user.username, display_name: user.display_name, bio: user.bio }
    })
  } catch (e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// Get profile
authRoutes.get('/me', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  return c.json({ user: { id: user.id, email: user.email, username: user.username, display_name: user.display_name, bio: user.bio, custom_skills: user.custom_skills } })
})

// Update profile
authRoutes.put('/profile', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { display_name, bio } = await c.req.json()
  await c.env.DB.prepare('UPDATE users SET display_name = ?, bio = ?, updated_at = datetime("now") WHERE id = ?')
    .bind(display_name || user.display_name, bio || user.bio, user.id).run()
  return c.json({ success: true })
})

// Update skills
authRoutes.put('/skills', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { custom_skills } = await c.req.json()
  await c.env.DB.prepare('UPDATE users SET custom_skills = ?, updated_at = datetime("now") WHERE id = ?')
    .bind(custom_skills, user.id).run()
  return c.json({ success: true })
})
