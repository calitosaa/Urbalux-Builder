import { Hono } from 'hono'
import { getUser, callAI, AI_KEYS } from '../lib/utils'

type Bindings = { DB: D1Database }
export const urblauxRoutes = new Hono<{ Bindings: Bindings }>()

// Urblaux Agent - unified super agent combining all models
urblauxRoutes.post('/chat', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { messages, model } = await c.req.json()
  
  // Route to appropriate provider based on model or use best available
  const response = await callAI(model || 'gemini', messages)
  return c.json({ response })
})

// Export Urblaux Agent as API key format
urblauxRoutes.get('/export', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  
  const exportKey = `urblaux_${user.id}_${Date.now().toString(36)}`
  const config = {
    key: exportKey,
    endpoint: '/api/urblaux/chat',
    providers: Object.keys(AI_KEYS).length,
    models_available: Object.entries(AI_KEYS).map(([k]) => k),
    capabilities: [
      'text_generation', 'code_generation', 'image_generation',
      'audio_generation', 'music_generation', 'video_generation',
      'web_search', 'semantic_search', 'vector_storage',
      'file_analysis', 'translation', 'summarization',
    ],
  }
  
  return c.json({ export: config })
})

// List all available models across all providers
urblauxRoutes.get('/models', async (c) => {
  const allModels: any[] = []
  const providerModels: Record<string, string[]> = {
    gemini: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'],
    openrouter: ['anthropic/claude-sonnet-4', 'google/gemini-2.5-pro', 'deepseek/deepseek-r1', 'openai/gpt-4.1'],
    mistral: ['mistral-large-latest', 'codestral-latest', 'magistral-medium-latest'],
    sambanova: ['DeepSeek-R1-0528', 'DeepSeek-V3.2', 'Llama-4-Maverick-17B-128E-Instruct'],
    cerebras: ['llama3.1-8b', 'qwen-3-235b-a22b-instruct-2507'],
    novita: ['meta-llama/llama-3.3-70b-instruct'],
    nvidia: ['meta/llama-3.3-70b-instruct'],
    xai: ['grok-3', 'grok-3-mini'],
    openai: ['gpt-4.1', 'gpt-4.1-mini', 'o4-mini'],
    fireworks: ['llama-v3p3-70b-instruct'],
    together: ['meta-llama/Llama-3.3-70B-Instruct-Turbo'],
    kimi: ['moonshot-v1-auto'],
    glm: ['glm-4-plus'],
  }

  for (const [provider, models] of Object.entries(providerModels)) {
    for (const model of models) {
      allModels.push({ provider, model, type: 'text' })
    }
  }
  
  // Add non-text models
  allModels.push({ provider: 'stability', model: 'stable-diffusion-xl', type: 'image' })
  allModels.push({ provider: 'replicate', model: 'black-forest-labs/flux', type: 'image' })
  allModels.push({ provider: 'elevenlabs', model: 'eleven_multilingual_v2', type: 'audio' })
  allModels.push({ provider: 'deepgram', model: 'nova-3', type: 'transcription' })
  allModels.push({ provider: 'suno', model: 'suno-v4', type: 'music' })
  allModels.push({ provider: 'runway', model: 'gen-3-alpha', type: 'video' })
  allModels.push({ provider: 'pollinations', model: 'flux', type: 'image' })

  return c.json({ models: allModels, total: allModels.length })
})
