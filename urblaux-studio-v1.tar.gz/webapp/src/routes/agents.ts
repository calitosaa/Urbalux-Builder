import { Hono } from 'hono'
import { getUser, AI_KEYS } from '../lib/utils'

type Bindings = { DB: D1Database }
export const agentRoutes = new Hono<{ Bindings: Bindings }>()

// List all available agents/models
agentRoutes.get('/', async (c) => {
  const providers = {
    gemini: { name: 'Google Gemini', models: ['gemini-2.5-flash','gemini-2.5-pro','gemini-2.0-flash','gemini-1.5-pro'], roles: ['director','thinker','programmer','search'], status: 'active' },
    openrouter: { name: 'OpenRouter', models: ['anthropic/claude-sonnet-4','google/gemini-2.5-pro','deepseek/deepseek-r1','meta-llama/llama-4-maverick','openai/gpt-4.1'], roles: ['programmer','thinker','verifier'], status: 'active' },
    mistral: { name: 'Mistral AI', models: ['mistral-large-latest','codestral-latest','mistral-small-latest','magistral-medium-latest','pixtral-large-latest'], roles: ['programmer','thinker','verifier'], status: 'active' },
    sambanova: { name: 'SambaNova', models: ['DeepSeek-R1-0528','DeepSeek-V3.2','Meta-Llama-3.3-70B-Instruct','Llama-4-Maverick-17B-128E-Instruct'], roles: ['thinker','programmer'], status: 'active' },
    cerebras: { name: 'Cerebras', models: ['llama3.1-8b','qwen-3-235b-a22b-instruct-2507'], roles: ['programmer','verifier'], status: 'active' },
    novita: { name: 'Novita AI', models: ['meta-llama/llama-3.3-70b-instruct','flux-1.1-pro'], roles: ['design','programmer','image_gen'], status: 'active' },
    cohere: { name: 'Cohere', models: ['command-r-plus-08-2024','command-r-08-2024'], roles: ['search','thinker'], status: 'active' },
    nvidia: { name: 'NVIDIA', models: ['meta/llama-3.3-70b-instruct','nvidia/llama-3.1-nemotron-ultra-253b-v1'], roles: ['programmer','thinker'], status: 'active' },
    xai: { name: 'xAI', models: ['grok-3','grok-3-mini'], roles: ['thinker','search','programmer'], status: 'active' },
    openai: { name: 'OpenAI', models: ['gpt-4.1','gpt-4.1-mini','o4-mini','dall-e-3','tts-1','whisper-1'], roles: ['director','programmer','thinker','image_gen','audio'], status: 'active' },
    deepgram: { name: 'Deepgram', models: ['nova-3'], roles: ['audio_transcription'], status: 'active' },
    elevenlabs: { name: 'ElevenLabs', models: ['eleven_multilingual_v2'], roles: ['audio_generation','tts'], status: 'active' },
    stability: { name: 'Stability AI', models: ['stable-diffusion-xl'], roles: ['image_gen','design'], status: 'active' },
    replicate: { name: 'Replicate', models: ['black-forest-labs/flux'], roles: ['image_gen'], status: 'active' },
    suno: { name: 'Suno', models: ['suno-v4'], roles: ['music_gen'], status: 'active' },
    runway: { name: 'Runway', models: ['gen-3-alpha'], roles: ['video_gen'], status: 'active' },
    fireworks: { name: 'Fireworks AI', models: ['llama-v3p3-70b-instruct'], roles: ['programmer'], status: 'active' },
    pollinations: { name: 'Pollinations', models: ['openai','flux'], roles: ['image_gen','text_gen'], status: 'active' },
    huggingface: { name: 'Hugging Face', models: ['meta-llama/Llama-3.3-70B-Instruct'], roles: ['programmer','thinker'], status: 'active' },
    tavily: { name: 'Tavily', models: ['search'], roles: ['search'], status: 'active' },
    pinecone: { name: 'Pinecone', models: ['serverless'], roles: ['vector_db','memory'], status: 'active' },
    edenai: { name: 'Eden AI', models: ['multi-provider'], roles: ['aggregator'], status: 'active' },
    kimi: { name: 'Kimi (Moonshot)', models: ['moonshot-v1-auto'], roles: ['thinker','programmer'], status: 'active' },
    glm: { name: 'GLM (Zhipu)', models: ['glm-4-plus','glm-4-flash'], roles: ['thinker','programmer'], status: 'active' },
    vercel: { name: 'Vercel', models: ['deploy'], roles: ['deploy'], status: 'active' },
    notion: { name: 'Notion', models: ['api-v1'], roles: ['knowledge_base'], status: 'active' },
    supabase: { name: 'Supabase', models: ['postgres','auth','storage'], roles: ['database','auth'], status: 'active' },
    together: { name: 'Together AI', models: ['meta-llama/Llama-3.3-70B-Instruct-Turbo','deepseek-ai/DeepSeek-V3'], roles: ['programmer','thinker'], status: 'active' },
    siliconflow: { name: 'SiliconFlow', models: ['deepseek-v3','qwen-2.5-72b'], roles: ['programmer'], status: 'active' },
  }
  
  const totalModels = Object.values(providers).reduce((t, p) => t + p.models.length, 0)
  return c.json({ providers, totalProviders: Object.keys(providers).length, totalModels })
})

// Get agent activity for a project
agentRoutes.get('/activity/:projectId', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const projectId = c.req.param('projectId')
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM agent_activity WHERE project_id = ? ORDER BY created_at DESC LIMIT 50')
      .bind(projectId).all()
    return c.json({ activity: results })
  } catch(e) {
    return c.json({ activity: [] })
  }
})
