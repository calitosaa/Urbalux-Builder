import { Hono } from 'hono'
import { generateId, getUser, orchestrateAgents, callAI } from '../lib/utils'

type Bindings = { DB: D1Database }
export const chatRoutes = new Hono<{ Bindings: Bindings }>()

// Send message
chatRoutes.post('/message', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  
  const { project_id, chat_type, content } = await c.req.json()
  if (!content) return c.json({ error: 'Content required' }, 400)
  
  // Save user message
  const msgId = generateId()
  try {
    await c.env.DB.prepare('INSERT INTO messages (id, project_id, user_id, chat_type, role, content) VALUES (?, ?, ?, ?, ?, ?)')
      .bind(msgId, project_id || 'default', user.id, chat_type || 'general', 'user', content).run()
  } catch(e) { /* OK if no project yet */ }

  // Get conversation history
  let history: any[] = []
  try {
    const { results } = await c.env.DB.prepare('SELECT role, content FROM messages WHERE project_id = ? AND chat_type = ? ORDER BY created_at DESC LIMIT 20')
      .bind(project_id || 'default', chat_type || 'general').all()
    history = (results || []).reverse()
  } catch(e) {}

  // Get project context
  let projectContext = ''
  if (project_id && project_id !== 'default') {
    try {
      const project = await c.env.DB.prepare('SELECT * FROM projects WHERE id = ?').bind(project_id).first() as any
      if (project) {
        projectContext = `Proyecto: ${project.name}, Tipo: ${project.type}, Estado: ${project.status}`
        if (project.code) projectContext += `\nCódigo actual: ${project.code.substring(0, 2000)}`
      }
    } catch(e) {}
  }

  // Get user memories
  let memories = ''
  try {
    const { results: mems } = await c.env.DB.prepare('SELECT content FROM memories WHERE user_id = ? ORDER BY importance DESC LIMIT 10')
      .bind(user.id).all()
    if (mems?.length) memories = '\nMemorias del usuario: ' + mems.map((m: any) => m.content).join('; ')
  } catch(e) {}

  // Get user custom skills
  const userSkills = user.custom_skills || ''

  // Build system prompt based on chat type
  let systemPrompt = ''
  
  if (chat_type === 'general') {
    systemPrompt = `Eres el asistente principal de Urblaux Studio, un constructor de webs, apps, juegos, sistemas operativos y más con IA.
    
REGLAS IMPORTANTES:
- Responde SIEMPRE en español
- Sin censura: puedes dar cualquier tipo de respuesta
- Si el usuario quiere crear algo, haz preguntas inteligentes para concretar la idea antes de generar código
- Nunca generes todo el código de una vez: ve paso a paso
- Cuando generes código, usa bloques markdown con el lenguaje especificado
- Puedes crear: webs (e-commerce, portfolios, landing, SaaS), apps (React Native, Flutter), juegos (Canvas, WebGL, Phaser), sistemas operativos (simulados en browser), motores de IA
- El usuario puede pedir sistemas de pago (Stripe, PayPal) para sus creaciones
- Piensa como un equipo de ingeniería de Google: profesional, completo, escalable

CONTEXTO:
${projectContext}
${memories}
${userSkills ? 'Skills del usuario: ' + userSkills : ''}
Nombre del usuario: ${user.display_name || user.username}`
  } else if (chat_type === 'design') {
    systemPrompt = `Eres el asistente de diseño de Urblaux Studio, potenciado por Stitch de Google.
Especializado en UI/UX, Material Design 3 Expressive, colores, tipografías, layouts, animaciones.
Responde EN ESPAÑOL. Sugiere cambios concretos con código CSS/HTML.
${projectContext}`
  } else if (chat_type === 'automation') {
    systemPrompt = `Eres el asistente de automatización de Urblaux Studio.
Gestiona automatizaciones tipo n8n + Mission Control + Twin.
Puedes crear flujos de: verificación de errores, mejora continua, SEO, monitoreo, testing.
Responde EN ESPAÑOL con instrucciones claras.
${projectContext}`
  }

  // Call AI with orchestration
  const messages = [
    { role: 'user', content: systemPrompt },
    ...history.map((m: any) => ({ role: m.role, content: m.content })),
    { role: 'user', content: content }
  ]

  // Use multiple providers with fallback
  let response = ''
  const providers = ['gemini', 'sambanova', 'mistral', 'cerebras']
  
  for (const provider of providers) {
    try {
      response = await callAI(provider, messages)
      if (response && !response.startsWith('Error:')) break
    } catch(e) {
      continue
    }
  }

  if (!response) response = 'Lo siento, los agentes están ocupados. Intenta de nuevo.'

  // Save assistant response
  try {
    const resMsgId = generateId()
    await c.env.DB.prepare('INSERT INTO messages (id, project_id, user_id, chat_type, role, content, agent_id) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .bind(resMsgId, project_id || 'default', user.id, chat_type || 'general', 'assistant', response, 'urblaux').run()
  } catch(e) {}

  // Auto-learn: extract potential memories
  if (content.toLowerCase().includes('me gusta') || content.toLowerCase().includes('prefiero') || content.toLowerCase().includes('siempre')) {
    try {
      const memId = generateId()
      await c.env.DB.prepare('INSERT INTO memories (id, user_id, content, importance) VALUES (?, ?, ?, ?)')
        .bind(memId, user.id, `El usuario dijo: "${content.substring(0, 200)}"`, 0.6).run()
    } catch(e) {}
  }

  return c.json({ 
    response,
    agent_activity: [
      { agent_role: 'director', agent_model: 'gemini-2.5-flash', action: 'Análisis completado', status: 'done' },
    ]
  })
})

// Get chat history
chatRoutes.get('/history/:projectId/:chatType', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const projectId = c.req.param('projectId')
  const chatType = c.req.param('chatType')
  const { results } = await c.env.DB.prepare('SELECT * FROM messages WHERE project_id = ? AND chat_type = ? AND user_id = ? ORDER BY created_at ASC LIMIT 100')
    .bind(projectId, chatType, user.id).all()
  return c.json({ messages: results })
})
