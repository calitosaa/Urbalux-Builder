import { Hono } from 'hono'
import { getUser } from '../lib/utils'

type Bindings = { DB: D1Database }
export const publishRoutes = new Hono<{ Bindings: Bindings }>()

// Publish project
publishRoutes.post('/', async (c) => {
  const user = await getUser(c)
  if (!user) return c.json({ error: 'Unauthorized' }, 401)
  const { platform, project_id } = await c.req.json()

  let project: any = null
  try {
    project = await c.env.DB.prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?').bind(project_id, user.id).first()
  } catch(e) {}

  if (!project) return c.json({ error: 'Project not found' }, 404)

  // For now, return deployment info based on platform
  const deployInfo: Record<string, any> = {
    vercel: {
      url: `https://${project.name.toLowerCase().replace(/\s+/g, '-')}.vercel.app`,
      instructions: 'Conecta tu repositorio GitHub con Vercel para deploy automático',
      platform: 'vercel',
    },
    github: {
      url: `https://${user.username}.github.io/${project.name.toLowerCase().replace(/\s+/g, '-')}`,
      instructions: 'Activa GitHub Pages en Settings > Pages de tu repositorio',
      platform: 'github',
    },
    cloudflare: {
      url: `https://${project.name.toLowerCase().replace(/\s+/g, '-')}.pages.dev`,
      instructions: 'Deploy via Cloudflare Pages con wrangler',
      platform: 'cloudflare',
    },
    download: {
      instructions: 'El código será descargado como ZIP',
      platform: 'download',
    },
    custom: {
      instructions: 'Configura tu dominio personalizado apuntando a tu servicio de hosting',
      platform: 'custom',
    },
  }

  const info = deployInfo[platform] || deployInfo.download

  // Update project status
  try {
    await c.env.DB.prepare('UPDATE projects SET status = ?, published_url = ?, updated_at = datetime("now") WHERE id = ?')
      .bind('published', info.url || '', project_id).run()
  } catch(e) {}

  return c.json(info)
})
