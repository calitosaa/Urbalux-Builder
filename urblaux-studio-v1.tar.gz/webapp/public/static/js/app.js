// ============================================================
// URBLAUX STUDIO - AI Web Builder Platform
// Material 3 Expressive | Multi-Agent | Full-Stack Builder
// ============================================================

// ---- STATE MANAGEMENT ----
const State = {
  user: null,
  token: null,
  currentProject: null,
  currentView: 'workspace',
  currentChat: 'general',
  messages: { general: [], design: [], automation: [] },
  agents: [],
  agentActivity: [],
  sources: [],
  automations: [],
  projects: [],
  memories: [],
  previewCode: '',
  panels: { left: true, right: true },
  isProcessing: false,
  theme: 'dark',
};

// ---- API HELPER ----
const API = {
  base: '/api',
  async fetch(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...options.headers };
    if (State.token) headers['Authorization'] = `Bearer ${State.token}`;
    try {
      const res = await fetch(`${this.base}${path}`, { ...options, headers });
      return await res.json();
    } catch (e) {
      console.error('API Error:', e);
      return { error: e.message };
    }
  },
  get: (p) => API.fetch(p),
  post: (p, d) => API.fetch(p, { method: 'POST', body: JSON.stringify(d) }),
  put: (p, d) => API.fetch(p, { method: 'PUT', body: JSON.stringify(d) }),
  del: (p) => API.fetch(p, { method: 'DELETE' }),
};

// ---- AI PROVIDERS REGISTRY ----
const AI_PROVIDERS = {
  gemini: {
    name: 'Google Gemini', icon: '🔷',
    models: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash', 'gemini-1.5-pro'],
    roles: ['director', 'thinker', 'programmer', 'search'],
    endpoint: 'https://generativelanguage.googleapis.com/v1beta',
  },
  openrouter: {
    name: 'OpenRouter', icon: '🌐',
    models: ['anthropic/claude-sonnet-4', 'google/gemini-2.5-pro', 'deepseek/deepseek-r1', 'meta-llama/llama-4-maverick', 'openai/gpt-4.1'],
    roles: ['programmer', 'thinker', 'verifier'],
    endpoint: 'https://openrouter.ai/api/v1',
  },
  mistral: {
    name: 'Mistral AI', icon: '🇫🇷',
    models: ['mistral-large-latest', 'codestral-latest', 'mistral-small-latest', 'magistral-medium-latest', 'pixtral-large-latest'],
    roles: ['programmer', 'thinker', 'verifier'],
    endpoint: 'https://api.mistral.ai/v1',
  },
  sambanova: {
    name: 'SambaNova', icon: '⚡',
    models: ['DeepSeek-R1-0528', 'DeepSeek-V3.2', 'Meta-Llama-3.3-70B-Instruct', 'Llama-4-Maverick-17B-128E-Instruct'],
    roles: ['thinker', 'programmer'],
    endpoint: 'https://api.sambanova.ai/v1',
  },
  cerebras: {
    name: 'Cerebras', icon: '🧠',
    models: ['llama3.1-8b', 'qwen-3-235b-a22b-instruct-2507'],
    roles: ['programmer', 'verifier'],
    endpoint: 'https://api.cerebras.ai/v1',
  },
  novita: {
    name: 'Novita AI', icon: '🎨',
    models: ['meta-llama/llama-3.3-70b-instruct', 'deepseek/deepseek-v3-0324', 'flux-1.1-pro'],
    roles: ['design', 'programmer', 'image_gen'],
    endpoint: 'https://api.novita.ai/v3/openai',
  },
  cohere: {
    name: 'Cohere', icon: '🔮',
    models: ['command-r-plus-08-2024', 'command-r-08-2024', 'command-nightly'],
    roles: ['search', 'thinker'],
    endpoint: 'https://api.cohere.com/v2',
  },
  nvidia: {
    name: 'NVIDIA', icon: '💚',
    models: ['meta/llama-3.3-70b-instruct', 'nvidia/llama-3.1-nemotron-ultra-253b-v1'],
    roles: ['programmer', 'thinker'],
    endpoint: 'https://integrate.api.nvidia.com/v1',
  },
  xai: {
    name: 'xAI', icon: '𝕏',
    models: ['grok-3', 'grok-3-mini', 'grok-2'],
    roles: ['thinker', 'search', 'programmer'],
    endpoint: 'https://api.x.ai/v1',
  },
  deepgram: {
    name: 'Deepgram', icon: '🎤',
    models: ['nova-3'],
    roles: ['audio_transcription'],
    endpoint: 'https://api.deepgram.com/v1',
  },
  elevenlabs: {
    name: 'ElevenLabs', icon: '🔊',
    models: ['eleven_multilingual_v2', 'eleven_turbo_v2'],
    roles: ['audio_generation', 'tts'],
    endpoint: 'https://api.elevenlabs.io/v1',
  },
  stability: {
    name: 'Stability AI', icon: '🖼️',
    models: ['stable-diffusion-xl', 'stable-image-ultra'],
    roles: ['image_gen', 'design'],
    endpoint: 'https://api.stability.ai/v1',
  },
  replicate: {
    name: 'Replicate', icon: '🔄',
    models: ['meta/llama-3.3-70b-instruct', 'stability-ai/sdxl', 'black-forest-labs/flux'],
    roles: ['image_gen', 'programmer'],
    endpoint: 'https://api.replicate.com/v1',
  },
  suno: {
    name: 'Suno', icon: '🎵',
    models: ['suno-v4'],
    roles: ['music_gen'],
    endpoint: 'https://api.suno.ai/v1',
  },
  runway: {
    name: 'Runway', icon: '🎬',
    models: ['gen-3-alpha'],
    roles: ['video_gen'],
    endpoint: 'https://api.runwayml.com/v1',
  },
  fireworks: {
    name: 'Fireworks AI', icon: '🎆',
    models: ['llama-v3p3-70b-instruct', 'mixtral-8x22b-instruct'],
    roles: ['programmer'],
    endpoint: 'https://api.fireworks.ai/inference/v1',
  },
  pollinations: {
    name: 'Pollinations', icon: '🌸',
    models: ['openai', 'flux'],
    roles: ['image_gen', 'text_gen'],
    endpoint: 'https://text.pollinations.ai',
  },
  huggingface: {
    name: 'Hugging Face', icon: '🤗',
    models: ['meta-llama/Llama-3.3-70B-Instruct', 'mistralai/Mixtral-8x7B-Instruct-v0.1'],
    roles: ['programmer', 'thinker'],
    endpoint: 'https://api-inference.huggingface.co/models',
  },
  tavily: {
    name: 'Tavily', icon: '🔍',
    models: ['search'],
    roles: ['search'],
    endpoint: 'https://api.tavily.com',
  },
  pinecone: {
    name: 'Pinecone', icon: '🌲',
    models: ['serverless'],
    roles: ['vector_db', 'memory'],
    endpoint: 'https://api.pinecone.io',
  },
  supabase: {
    name: 'Supabase', icon: '⚡',
    models: ['postgres', 'auth', 'storage'],
    roles: ['database', 'auth'],
    endpoint: 'https://supabase.co',
  },
  notion: {
    name: 'Notion', icon: '📝',
    models: ['api-v1'],
    roles: ['knowledge_base', 'docs'],
    endpoint: 'https://api.notion.com/v1',
  },
  openai: {
    name: 'OpenAI', icon: '🤖',
    models: ['gpt-4.1', 'gpt-4.1-mini', 'o4-mini', 'dall-e-3', 'tts-1', 'whisper-1'],
    roles: ['director', 'programmer', 'thinker', 'image_gen', 'audio'],
    endpoint: 'https://api.openai.com/v1',
  },
  edenai: {
    name: 'Eden AI', icon: '🌿',
    models: ['multi-provider'],
    roles: ['aggregator'],
    endpoint: 'https://api.edenai.run/v2',
  },
  vercel: {
    name: 'Vercel', icon: '▲',
    models: ['deploy'],
    roles: ['deploy'],
    endpoint: 'https://api.vercel.com',
  },
  kimi: {
    name: 'Kimi (Moonshot)', icon: '🌙',
    models: ['moonshot-v1-auto', 'moonshot-v1-128k'],
    roles: ['thinker', 'programmer'],
    endpoint: 'https://api.moonshot.cn/v1',
  },
  glm: {
    name: 'GLM (Zhipu)', icon: '🐲',
    models: ['glm-4-plus', 'glm-4-flash'],
    roles: ['thinker', 'programmer'],
    endpoint: 'https://open.bigmodel.cn/api/paas/v4',
  },
};

// ---- AGENT ROLES ----
const AGENT_ROLES = {
  director: { name: 'Director', icon: '👑', desc: 'Orchestrates the entire process, delegates tasks', color: 'primary' },
  search: { name: 'Buscador', icon: '🔍', desc: 'Searches information online and in sources', color: 'tertiary' },
  thinker: { name: 'Pensador', icon: '🧠', desc: 'Logical thinking, architecture, planning', color: 'secondary' },
  programmer: { name: 'Programador', icon: '💻', desc: 'Writes and refactors code', color: 'primary' },
  verifier: { name: 'Verificador', icon: '✅', desc: 'Tests, detects errors, validates quality', color: 'tertiary' },
  design: { name: 'Diseñador', icon: '🎨', desc: 'UI/UX design powered by Stitch', color: 'secondary' },
  automation: { name: 'Automatizador', icon: '⚙️', desc: 'Creates and manages automations', color: 'primary' },
};

// ---- RENDER ENGINE ----
function $(sel) { return document.querySelector(sel); }
function $$(sel) { return document.querySelectorAll(sel); }
function html(el, content) { if (el) el.innerHTML = content; }
function show(el) { if (el) el.classList.add('active'); }
function hide(el) { if (el) el.classList.remove('active'); }

// ---- MAIN RENDER ----
function renderMainApp() {
  const root = $('#app-root');
  if (!State.user) {
    renderAuth(root);
    return;
  }
  root.innerHTML = `
    <!-- Navigation Rail -->
    <nav class="nav-rail" id="nav-rail">
      <div class="logo m3-spring" onclick="App.goHome()">U</div>
      <div class="nav-item active" data-view="workspace" onclick="App.switchView('workspace')">
        <div class="icon-container"><span class="material-symbols-outlined">code</span></div>
        <span class="label">Builder</span>
      </div>
      <div class="nav-item" data-view="pomelli" onclick="App.switchView('pomelli')">
        <div class="icon-container"><span class="material-symbols-outlined">palette</span></div>
        <span class="label">Pomelli</span>
      </div>
      <div class="nav-item" data-view="automation" onclick="App.switchView('automation')">
        <div class="icon-container"><span class="material-symbols-outlined">settings_suggest</span></div>
        <span class="label">Auto</span>
      </div>
      <div class="nav-item" data-view="agents" onclick="App.switchView('agents')">
        <div class="icon-container"><span class="material-symbols-outlined">group</span></div>
        <span class="label">Agentes</span>
      </div>
      <div class="nav-item" data-view="publish" onclick="App.switchView('publish')">
        <div class="icon-container"><span class="material-symbols-outlined">cloud_upload</span></div>
        <span class="label">Publicar</span>
      </div>
      <div class="nav-item" data-view="projects" onclick="App.switchView('projects')">
        <div class="icon-container"><span class="material-symbols-outlined">folder</span></div>
        <span class="label">Proyectos</span>
      </div>
      <div class="nav-item" data-view="settings" onclick="App.switchView('settings')">
        <div class="icon-container"><span class="material-symbols-outlined">settings</span></div>
        <span class="label">Config</span>
      </div>
      <div style="flex:1"></div>
      <div class="nav-item" onclick="App.showProfile()">
        <div class="icon-container"><span class="material-symbols-outlined">account_circle</span></div>
        <span class="label">${State.user?.username || 'User'}</span>
      </div>
    </nav>

    <!-- Main Area -->
    <div class="main-area">
      <!-- Top Bar -->
      <header class="top-bar">
        <button class="m3-btn-icon" onclick="App.togglePanel('left')">
          <span class="material-symbols-outlined">menu</span>
        </button>
        <h3 style="font-size:16px;font-weight:500;color:var(--on-surface);margin:0;flex:1">
          ${State.currentProject ? State.currentProject.name : 'Urblaux Studio'}
        </h3>
        <div style="display:flex;gap:4px;align-items:center">
          <button class="m3-btn-icon" onclick="App.newProject()">
            <span class="material-symbols-outlined">add</span>
          </button>
          <button class="m3-btn-icon" onclick="App.togglePanel('right')">
            <span class="material-symbols-outlined">right_panel_open</span>
          </button>
        </div>
      </header>

      <!-- Content Area -->
      <div class="content-area" id="content-area">
        ${renderWorkspaceView()}
        ${renderPomelliView()}
        ${renderAutomationView()}
        ${renderAgentsView()}
        ${renderPublishView()}
        ${renderProjectsView()}
        ${renderSettingsView()}
      </div>
    </div>

    <!-- Dialogs -->
    <div class="m3-dialog-overlay" id="dialog-overlay">
      <div class="m3-dialog" id="dialog-content"></div>
    </div>
  `;
  
  // Show current view
  const currentView = $(`.view[data-view="${State.currentView}"]`);
  if (currentView) currentView.classList.add('active');
  
  initEventListeners();
}

// ---- WORKSPACE VIEW (Main Builder) ----
function renderWorkspaceView() {
  return `
  <div class="view active" data-view="workspace" style="flex-direction:row !important">
    <!-- Left Panel - Sources + Files -->
    <div class="panel-left" id="panel-left">
      <div class="panel-header">
        <span class="material-symbols-outlined" style="font-size:20px;color:var(--primary)">source</span>
        <span style="font-weight:500;font-size:14px">Fuentes</span>
        <div style="flex:1"></div>
        <button class="m3-btn-icon" onclick="App.addSource()" style="width:32px;height:32px">
          <span class="material-symbols-outlined" style="font-size:18px">add</span>
        </button>
      </div>
      <div class="m3-tabs" style="padding:0 8px">
        <button class="m3-tab active" onclick="App.switchLeftTab('sources')">Fuentes</button>
        <button class="m3-tab" onclick="App.switchLeftTab('files')">Archivos</button>
        <button class="m3-tab" onclick="App.switchLeftTab('agents-log')">Agentes</button>
      </div>
      <div class="panel-content" id="left-panel-content">
        ${renderSourcesPanel()}
      </div>
    </div>

    <!-- Center Panel - Chat + Preview -->
    <div class="panel-center">
      <div class="m3-tabs" id="center-tabs">
        <button class="m3-tab active" onclick="App.switchCenterTab('chat')">
          <span class="material-symbols-outlined" style="font-size:18px">chat</span> Chat General
        </button>
        <button class="m3-tab" onclick="App.switchCenterTab('preview')">
          <span class="material-symbols-outlined" style="font-size:18px">visibility</span> Preview
        </button>
        <button class="m3-tab" onclick="App.switchCenterTab('code')">
          <span class="material-symbols-outlined" style="font-size:18px">code</span> Codigo
        </button>
      </div>
      <div id="center-content" style="flex:1;display:flex;flex-direction:column;overflow:hidden">
        ${renderChatPanel('general')}
      </div>
    </div>

    <!-- Right Panel - Design Chat -->
    <div class="panel-right" id="panel-right">
      <div class="panel-header">
        <span class="material-symbols-outlined" style="font-size:20px;color:var(--tertiary)">brush</span>
        <span style="font-weight:500;font-size:14px">Diseño</span>
        <div style="flex:1"></div>
        <div class="m3-chip selected" style="font-size:11px">Stitch</div>
      </div>
      <div class="chat-container" id="design-chat-container">
        <div class="chat-messages" id="design-messages">
          <div class="msg assistant m3-fade-up">
            <div class="msg-avatar">🎨</div>
            <div class="msg-bubble">
              ¡Hola! Soy tu asistente de diseño, potenciado por <strong>Stitch</strong> y respaldado por múltiples IAs de diseño. Puedo cambiar colores, layouts, tipografías, animaciones y todo lo visual de tu creación. ¿Qué quieres ajustar?
            </div>
          </div>
        </div>
        <div class="chat-input-area">
          <div style="display:flex;gap:4px;flex-wrap:wrap;padding:0 4px">
            <span class="m3-chip" onclick="App.designQuick('colors')">🎨 Colores</span>
            <span class="m3-chip" onclick="App.designQuick('layout')">📐 Layout</span>
            <span class="m3-chip" onclick="App.designQuick('typo')">🔤 Tipografía</span>
            <span class="m3-chip" onclick="App.designQuick('anim')">✨ Animaciones</span>
          </div>
          <div class="chat-input-row">
            <button class="m3-btn-icon" onclick="App.uploadDesignFile()">
              <span class="material-symbols-outlined">attach_file</span>
            </button>
            <textarea class="chat-input" id="design-input" placeholder="Describe el cambio de diseño..." rows="1"
              onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();App.sendDesignMsg()}"></textarea>
            <button class="m3-btn-icon" style="color:var(--primary)" onclick="App.sendDesignMsg()">
              <span class="material-symbols-outlined">send</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

// ---- SOURCES PANEL ----
function renderSourcesPanel() {
  return `
    <div style="padding:8px">
      <div class="upload-area" id="source-upload"
        ondrop="App.handleSourceDrop(event)" ondragover="event.preventDefault();this.classList.add('dragover')"
        ondragleave="this.classList.remove('dragover')">
        <span class="material-symbols-outlined" style="font-size:32px;color:var(--primary)">cloud_upload</span>
        <p style="margin:8px 0 0;font-size:13px;color:var(--on-surface-variant)">
          Arrastra archivos, URLs, audios, imágenes o videos
        </p>
      </div>
      <div style="margin-top:12px;display:flex;gap:6px;flex-wrap:wrap">
        <span class="m3-chip" onclick="App.addUrlSource()">🔗 URL</span>
        <span class="m3-chip" onclick="App.addTextSource()">📝 Texto</span>
        <span class="m3-chip" onclick="App.searchSources()">🔍 Buscar auto</span>
      </div>
      <div id="sources-list" style="margin-top:12px" class="m3-stagger">
        ${State.sources.map(s => `
          <div class="source-card">
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:16px">${s.type === 'url' ? '🔗' : s.type === 'file' ? '📄' : '📝'}</span>
              <span style="font-size:13px;font-weight:500;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${s.title || 'Sin título'}</span>
              ${s.auto_added ? '<span class="m3-chip" style="font-size:10px">Auto</span>' : ''}
              <button class="m3-btn-icon" style="width:28px;height:28px" onclick="App.removeSource('${s.id}')">
                <span class="material-symbols-outlined" style="font-size:16px">close</span>
              </button>
            </div>
          </div>
        `).join('')}
        ${State.sources.length === 0 ? '<p style="text-align:center;color:var(--on-surface-variant);font-size:13px;padding:16px">Aún no hay fuentes. Agrega URLs, archivos o deja que la IA busque automáticamente.</p>' : ''}
      </div>
    </div>`;
}

// ---- CHAT PANEL ----
function renderChatPanel(type) {
  const msgs = State.messages[type] || [];
  const welcome = type === 'general' 
    ? '¡Bienvenido a Urblaux Studio! Describe lo que quieres crear: una web, app, juego, sistema operativo, o lo que imagines. Puedo crear desde sitios de e-commerce hasta motores de IA completos. ¡Te haré preguntas inteligentes para concretar tu idea!'
    : type === 'design'
    ? 'Soy tu diseñador. Potenciado por Stitch y respaldado por IA. ¿Qué quieres cambiar?'
    : 'Gestiona tus automatizaciones. Crea flujos tipo n8n, Mission Control y Twin.';

  return `
  <div class="chat-container">
    <div class="chat-messages" id="${type}-messages">
      <div class="msg assistant m3-fade-up">
        <div class="msg-avatar">${type === 'general' ? '⚡' : type === 'design' ? '🎨' : '⚙️'}</div>
        <div class="msg-bubble">${welcome}</div>
      </div>
      ${msgs.map(m => `
        <div class="msg ${m.role} m3-fade-up">
          <div class="msg-avatar">${m.role === 'user' ? '👤' : m.agent_icon || '⚡'}</div>
          <div class="msg-bubble">${formatMessage(m.content)}</div>
        </div>
      `).join('')}
    </div>
    <!-- Agent Activity Bar -->
    <div id="agent-bar" style="display:${State.isProcessing ? 'flex' : 'none'};gap:8px;padding:8px 16px;overflow-x:auto;border-top:1px solid var(--outline-variant)">
      ${State.agentActivity.filter(a => a.status === 'running').map(a => `
        <div class="agent-status running" style="white-space:nowrap">
          ${AGENT_ROLES[a.agent_role]?.icon || '🤖'} ${AGENT_ROLES[a.agent_role]?.name || a.agent_role}: ${a.action}
        </div>
      `).join('')}
    </div>
    <div class="chat-input-area">
      <div style="display:flex;gap:4px;flex-wrap:wrap;padding:0 4px" id="chat-chips">
        ${type === 'general' ? `
          <span class="m3-chip" onclick="App.quickPrompt('web')">🌐 Web</span>
          <span class="m3-chip" onclick="App.quickPrompt('app')">📱 App</span>
          <span class="m3-chip" onclick="App.quickPrompt('game')">🎮 Juego</span>
          <span class="m3-chip" onclick="App.quickPrompt('os')">💻 S.O.</span>
          <span class="m3-chip" onclick="App.quickPrompt('ai')">🤖 Motor IA</span>
          <span class="m3-chip" onclick="App.quickPrompt('ecommerce')">🛒 Tienda</span>
        ` : ''}
      </div>
      <div class="chat-input-row">
        <button class="m3-btn-icon" onclick="App.uploadFile()">
          <span class="material-symbols-outlined">attach_file</span>
        </button>
        <button class="m3-btn-icon" onclick="App.recordAudio()">
          <span class="material-symbols-outlined">mic</span>
        </button>
        <textarea class="chat-input" id="${type}-input" placeholder="Describe tu idea..." rows="1"
          onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();App.sendMessage('${type}')}"></textarea>
        <button class="m3-btn-icon" onclick="App.searchWeb()" title="Buscar en web">
          <span class="material-symbols-outlined">travel_explore</span>
        </button>
        <button class="m3-btn-icon" style="color:var(--primary)" onclick="App.sendMessage('${type}')">
          <span class="material-symbols-outlined">send</span>
        </button>
      </div>
    </div>
  </div>`;
}

// ---- POMELLI VIEW ----
function renderPomelliView() {
  return `
  <div class="view" data-view="pomelli" style="flex-direction:column !important">
    <div style="padding:24px;flex:1;overflow-y:auto">
      <div class="m3-spring" style="max-width:800px;margin:0 auto">
        <div style="text-align:center;margin-bottom:32px">
          <div style="width:80px;height:80px;border-radius:24px;background:var(--tertiary-container);display:inline-flex;align-items:center;justify-content:center;font-size:40px;margin-bottom:16px">🎯</div>
          <h2 style="font-size:28px;font-weight:700;color:var(--on-surface);margin:0 0 8px">Pomelli</h2>
          <p style="color:var(--on-surface-variant);font-size:15px;max-width:500px;margin:0 auto">
            Genera contenido de marca personalizado para tu creación. Análisis de identidad visual, campañas y assets creativos.
          </p>
        </div>
        ${State.currentProject ? `
          <div class="m3-card" style="margin-bottom:16px">
            <h3 style="font-size:16px;margin:0 0 12px">📊 Business DNA</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
              <div style="padding:12px;background:var(--surface-container-high);border-radius:12px">
                <div style="font-size:12px;color:var(--on-surface-variant)">Nombre</div>
                <div style="font-weight:500;margin-top:4px">${State.currentProject.name}</div>
              </div>
              <div style="padding:12px;background:var(--surface-container-high);border-radius:12px">
                <div style="font-size:12px;color:var(--on-surface-variant)">Tipo</div>
                <div style="font-weight:500;margin-top:4px">${State.currentProject.type}</div>
              </div>
              <div style="padding:12px;background:var(--surface-container-high);border-radius:12px">
                <div style="font-size:12px;color:var(--on-surface-variant)">Estado</div>
                <div style="font-weight:500;margin-top:4px">${State.currentProject.status}</div>
              </div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px">
            <div class="m3-card" style="cursor:pointer" onclick="App.pomelliAction('campaign')">
              <span style="font-size:28px">📣</span>
              <h4 style="margin:8px 0 4px;font-size:15px">Crear Campaña</h4>
              <p style="font-size:13px;color:var(--on-surface-variant);margin:0">Genera ideas de campaña de marketing on-brand</p>
            </div>
            <div class="m3-card" style="cursor:pointer" onclick="App.pomelliAction('social')">
              <span style="font-size:28px">📱</span>
              <h4 style="margin:8px 0 4px;font-size:15px">Social Media</h4>
              <p style="font-size:13px;color:var(--on-surface-variant);margin:0">Posts para todas las redes sociales</p>
            </div>
            <div class="m3-card" style="cursor:pointer" onclick="App.pomelliAction('logo')">
              <span style="font-size:28px">✨</span>
              <h4 style="margin:8px 0 4px;font-size:15px">Logo & Brand</h4>
              <p style="font-size:13px;color:var(--on-surface-variant);margin:0">Genera logos y guía de estilo</p>
            </div>
            <div class="m3-card" style="cursor:pointer" onclick="App.pomelliAction('photoshoot')">
              <span style="font-size:28px">📸</span>
              <h4 style="margin:8px 0 4px;font-size:15px">Photoshoot</h4>
              <p style="font-size:13px;color:var(--on-surface-variant);margin:0">Fotos de producto con IA</p>
            </div>
          </div>
        ` : `
          <div style="text-align:center;padding:40px">
            <span class="material-symbols-outlined" style="font-size:48px;color:var(--on-surface-variant)">info</span>
            <p style="color:var(--on-surface-variant)">Crea un proyecto primero para usar Pomelli</p>
            <button class="m3-btn m3-btn-filled" onclick="App.newProject()">Nuevo Proyecto</button>
          </div>
        `}
      </div>
    </div>
  </div>`;
}

// ---- AUTOMATION VIEW (Mission Control + Twin + n8n) ----
function renderAutomationView() {
  return `
  <div class="view" data-view="automation" style="flex-direction:row !important">
    <!-- Automation List -->
    <div style="width:320px;border-right:1px solid var(--outline-variant);display:flex;flex-direction:column">
      <div class="panel-header">
        <span class="material-symbols-outlined" style="color:var(--primary)">settings_suggest</span>
        <span style="font-weight:500">Mission Control</span>
        <div style="flex:1"></div>
        <button class="m3-btn-icon" onclick="App.createAutomation()" style="width:32px;height:32px">
          <span class="material-symbols-outlined" style="font-size:18px">add</span>
        </button>
      </div>
      <div style="flex:1;overflow-y:auto;padding:12px" id="automation-list">
        <div class="auto-card" onclick="App.selectAutomation('auto-error-check')">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="font-size:18px">🔍</span>
            <span style="font-weight:500;font-size:14px;flex:1">Error Checker</span>
            <span class="agent-status idle">Pausado</span>
          </div>
          <p style="font-size:12px;color:var(--on-surface-variant);margin:0">
            Los agentes verifican y testean la web periódicamente como humanos
          </p>
          <div style="margin-top:8px;display:flex;gap:4px">
            <span class="m3-chip" style="font-size:10px">✅ Verificador</span>
            <span class="m3-chip" style="font-size:10px">🧠 Pensador</span>
          </div>
        </div>
        <div class="auto-card" onclick="App.selectAutomation('auto-improve')">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="font-size:18px">🚀</span>
            <span style="font-weight:500;font-size:14px;flex:1">Mejora Continua</span>
            <span class="agent-status idle">Pausado</span>
          </div>
          <p style="font-size:12px;color:var(--on-surface-variant);margin:0">
            Busca en internet y redes sociales mejoras para tu creación
          </p>
        </div>
        <div class="auto-card" onclick="App.selectAutomation('auto-seo')">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="font-size:18px">📈</span>
            <span style="font-weight:500;font-size:14px;flex:1">SEO & Analytics</span>
            <span class="agent-status idle">Pausado</span>
          </div>
          <p style="font-size:12px;color:var(--on-surface-variant);margin:0">
            Optimiza SEO y analiza métricas automáticamente
          </p>
        </div>
      </div>
    </div>
    <!-- Automation Detail / Chat -->
    <div style="flex:1;display:flex;flex-direction:column">
      <div class="m3-tabs">
        <button class="m3-tab active" onclick="App.switchAutoTab('chat')">💬 Chat</button>
        <button class="m3-tab" onclick="App.switchAutoTab('flow')">🔄 Flujo</button>
        <button class="m3-tab" onclick="App.switchAutoTab('logs')">📋 Logs</button>
      </div>
      <div style="flex:1;overflow:hidden" id="auto-detail-content">
        ${renderChatPanel('automation')}
      </div>
    </div>
  </div>`;
}

// ---- AGENTS VIEW ----
function renderAgentsView() {
  return `
  <div class="view" data-view="agents" style="flex-direction:column !important">
    <div style="padding:24px;flex:1;overflow-y:auto">
      <div style="max-width:1000px;margin:0 auto">
        <h2 style="font-size:24px;font-weight:700;margin:0 0 8px">🤖 Agentes de IA</h2>
        <p style="color:var(--on-surface-variant);font-size:14px;margin:0 0 24px">
          ${Object.values(AI_PROVIDERS).reduce((t, p) => t + p.models.length, 0)} modelos de IA disponibles de ${Object.keys(AI_PROVIDERS).length} proveedores. 
          Todos trabajando coordinados.
        </p>
        
        <!-- Urblaux Agent -->
        <div class="m3-card" style="background:linear-gradient(135deg,var(--primary-container),var(--tertiary-container));margin-bottom:24px;padding:24px">
          <div style="display:flex;align-items:center;gap:16px">
            <div style="width:64px;height:64px;border-radius:20px;background:var(--primary);color:var(--on-primary);display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700">U</div>
            <div style="flex:1">
              <h3 style="margin:0;font-size:20px;font-weight:700">Urblaux Agent</h3>
              <p style="margin:4px 0 0;font-size:13px;opacity:0.8">Super-agente unificado - Combina TODOS los modelos de IA en uno solo</p>
            </div>
            <button class="m3-btn m3-btn-filled" onclick="App.exportUrblaux()">
              <span class="material-symbols-outlined" style="font-size:18px">download</span>
              Exportar API
            </button>
          </div>
        </div>

        <!-- Agent Roles -->
        <h3 style="font-size:16px;margin:0 0 12px">Roles del equipo</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:24px" class="m3-stagger">
          ${Object.entries(AGENT_ROLES).map(([key, role]) => `
            <div class="m3-card" style="cursor:pointer" onclick="App.configAgent('${key}')">
              <div style="font-size:24px;margin-bottom:8px">${role.icon}</div>
              <div style="font-weight:600;font-size:14px">${role.name}</div>
              <div style="font-size:12px;color:var(--on-surface-variant);margin-top:4px">${role.desc}</div>
            </div>
          `).join('')}
        </div>

        <!-- Providers -->
        <h3 style="font-size:16px;margin:0 0 12px">Proveedores de IA (${Object.keys(AI_PROVIDERS).length})</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px" class="m3-stagger">
          ${Object.entries(AI_PROVIDERS).map(([key, prov]) => `
            <div class="m3-card">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                <span style="font-size:20px">${prov.icon}</span>
                <span style="font-weight:600;font-size:14px;flex:1">${prov.name}</span>
                <span class="agent-status done">${prov.models.length} modelos</span>
              </div>
              <div style="display:flex;gap:4px;flex-wrap:wrap">
                ${prov.models.slice(0, 4).map(m => `<span class="m3-chip" style="font-size:10px">${m}</span>`).join('')}
                ${prov.models.length > 4 ? `<span class="m3-chip" style="font-size:10px">+${prov.models.length - 4}</span>` : ''}
              </div>
              <div style="margin-top:8px;display:flex;gap:4px;flex-wrap:wrap">
                ${prov.roles.map(r => `<span style="font-size:11px;color:var(--on-surface-variant)">${AGENT_ROLES[r]?.icon || '🔧'} ${AGENT_ROLES[r]?.name || r}</span>`).join(' · ')}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  </div>`;
}

// ---- PUBLISH VIEW ----
function renderPublishView() {
  return `
  <div class="view" data-view="publish" style="flex-direction:column !important">
    <div style="padding:24px;flex:1;overflow-y:auto">
      <div style="max-width:700px;margin:0 auto">
        <h2 style="font-size:24px;font-weight:700;margin:0 0 24px">🚀 Publicar</h2>
        <div style="display:grid;gap:16px" class="m3-stagger">
          <div class="m3-card" style="cursor:pointer" onclick="App.publishTo('vercel')">
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:32px">▲</span>
              <div style="flex:1">
                <div style="font-weight:600">Vercel</div>
                <div style="font-size:13px;color:var(--on-surface-variant)">Deploy instantáneo con dominio .vercel.app</div>
              </div>
              <span class="material-symbols-outlined">arrow_forward</span>
            </div>
          </div>
          <div class="m3-card" style="cursor:pointer" onclick="App.publishTo('github')">
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:32px">🐙</span>
              <div style="flex:1">
                <div style="font-weight:600">GitHub Pages</div>
                <div style="font-size:13px;color:var(--on-surface-variant)">Publica directamente en GitHub Pages</div>
              </div>
              <span class="material-symbols-outlined">arrow_forward</span>
            </div>
          </div>
          <div class="m3-card" style="cursor:pointer" onclick="App.publishTo('cloudflare')">
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:32px">☁️</span>
              <div style="flex:1">
                <div style="font-weight:600">Cloudflare Pages</div>
                <div style="font-size:13px;color:var(--on-surface-variant)">Edge deployment global con Workers</div>
              </div>
              <span class="material-symbols-outlined">arrow_forward</span>
            </div>
          </div>
          <div class="m3-card" style="cursor:pointer" onclick="App.publishTo('download')">
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:32px">💾</span>
              <div style="flex:1">
                <div style="font-weight:600">Descargar</div>
                <div style="font-size:13px;color:var(--on-surface-variant)">Descarga el código completo como ZIP</div>
              </div>
              <span class="material-symbols-outlined">arrow_forward</span>
            </div>
          </div>
          <div class="m3-card" style="cursor:pointer" onclick="App.publishTo('custom')">
            <div style="display:flex;align-items:center;gap:12px">
              <span style="font-size:32px">🌍</span>
              <div style="flex:1">
                <div style="font-weight:600">Dominio Personalizado</div>
                <div style="font-size:13px;color:var(--on-surface-variant)">Conecta tu propio dominio</div>
              </div>
              <span class="material-symbols-outlined">arrow_forward</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

// ---- PROJECTS VIEW ----
function renderProjectsView() {
  return `
  <div class="view" data-view="projects" style="flex-direction:column !important">
    <div style="padding:24px;flex:1;overflow-y:auto">
      <div style="max-width:900px;margin:0 auto">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px">
          <h2 style="font-size:24px;font-weight:700;margin:0;flex:1">📁 Mis Proyectos</h2>
          <button class="m3-btn m3-btn-filled" onclick="App.newProject()">
            <span class="material-symbols-outlined" style="font-size:18px">add</span> Nuevo
          </button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px" id="projects-grid" class="m3-stagger">
          ${State.projects.length === 0 ? `
            <div style="grid-column:1/-1;text-align:center;padding:60px 0">
              <span class="material-symbols-outlined" style="font-size:64px;color:var(--on-surface-variant)">folder_open</span>
              <p style="color:var(--on-surface-variant);font-size:16px">No tienes proyectos aún</p>
              <button class="m3-btn m3-btn-filled" onclick="App.newProject()">Crear mi primer proyecto</button>
            </div>
          ` : State.projects.map(p => `
            <div class="m3-card" style="cursor:pointer" onclick="App.openProject('${p.id}')">
              <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                <span style="font-size:20px">${p.type === 'web' ? '🌐' : p.type === 'app' ? '📱' : p.type === 'game' ? '🎮' : '💻'}</span>
                <span style="font-weight:600;flex:1">${p.name}</span>
                <span class="agent-status ${p.status === 'published' ? 'done' : 'idle'}">${p.status}</span>
              </div>
              <p style="font-size:13px;color:var(--on-surface-variant);margin:0">${p.description || 'Sin descripción'}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  </div>`;
}

// ---- SETTINGS VIEW ----
function renderSettingsView() {
  return `
  <div class="view" data-view="settings" style="flex-direction:column !important">
    <div style="padding:24px;flex:1;overflow-y:auto">
      <div style="max-width:700px;margin:0 auto">
        <h2 style="font-size:24px;font-weight:700;margin:0 0 24px">⚙️ Configuración</h2>
        
        <div class="m3-card" style="margin-bottom:16px">
          <h3 style="font-size:16px;margin:0 0 12px">👤 Perfil</h3>
          <div style="display:grid;gap:8px">
            <input class="auth-input" value="${State.user?.display_name || ''}" placeholder="Nombre" id="settings-name" style="margin:0">
            <input class="auth-input" value="${State.user?.email || ''}" placeholder="Email" id="settings-email" style="margin:0" disabled>
            <textarea class="auth-input" placeholder="Bio" id="settings-bio" style="margin:0;min-height:60px;resize:vertical">${State.user?.bio || ''}</textarea>
            <button class="m3-btn m3-btn-tonal" onclick="App.saveProfile()">Guardar perfil</button>
          </div>
        </div>

        <div class="m3-card" style="margin-bottom:16px">
          <h3 style="font-size:16px;margin:0 0 12px">🧠 Memorias de IA</h3>
          <p style="font-size:13px;color:var(--on-surface-variant);margin:0 0 12px">
            La IA aprende de ti para personalizar las respuestas. Puedes ver y gestionar tus memorias.
          </p>
          <div id="memories-list" style="display:grid;gap:8px">
            ${State.memories.map(m => `
              <div style="display:flex;gap:8px;align-items:center;padding:8px;background:var(--surface-container-high);border-radius:8px">
                <span style="font-size:13px;flex:1">${m.content}</span>
                <button class="m3-btn-icon" style="width:28px;height:28px" onclick="App.deleteMemory('${m.id}')">
                  <span class="material-symbols-outlined" style="font-size:16px">delete</span>
                </button>
              </div>
            `).join('')}
          </div>
          <button class="m3-btn m3-btn-outlined" style="margin-top:8px" onclick="App.addMemory()">+ Añadir memoria</button>
        </div>

        <div class="m3-card" style="margin-bottom:16px">
          <h3 style="font-size:16px;margin:0 0 12px">🔧 Skills Personalizadas</h3>
          <p style="font-size:13px;color:var(--on-surface-variant);margin:0 0 12px">
            Añade instrucciones o skills extras para que los agentes de IA las usen.
          </p>
          <textarea class="auth-input" id="custom-skills" placeholder="Escribe instrucciones o skills..." 
            style="margin:0;min-height:100px;resize:vertical">${State.user?.custom_skills || ''}</textarea>
          <button class="m3-btn m3-btn-tonal" style="margin-top:8px" onclick="App.saveSkills()">Guardar Skills</button>
        </div>

        <div class="m3-card" style="margin-bottom:16px">
          <h3 style="font-size:16px;margin:0 0 12px">🎨 Tema</h3>
          <div style="display:flex;gap:8px">
            <button class="m3-btn ${State.theme === 'dark' ? 'm3-btn-filled' : 'm3-btn-outlined'}" onclick="App.setTheme('dark')">🌙 Oscuro</button>
            <button class="m3-btn ${State.theme === 'light' ? 'm3-btn-filled' : 'm3-btn-outlined'}" onclick="App.setTheme('light')">☀️ Claro</button>
          </div>
        </div>

        <div class="m3-card">
          <h3 style="font-size:16px;margin:0 0 12px">🔴 Zona de peligro</h3>
          <button class="m3-btn m3-btn-outlined" style="color:var(--error);border-color:var(--error)" onclick="App.logout()">Cerrar Sesión</button>
        </div>
      </div>
    </div>
  </div>`;
}

// ---- AUTH SCREEN ----
function renderAuth(root) {
  root.innerHTML = `
  <div class="auth-screen">
    <div class="auth-card m3-spring">
      <div style="text-align:center;margin-bottom:32px">
        <div style="width:72px;height:72px;border-radius:20px;background:var(--primary);color:var(--on-primary);display:inline-flex;align-items:center;justify-content:center;font-size:32px;font-weight:700;margin-bottom:16px">U</div>
        <h1 style="font-size:28px;font-weight:700;margin:0;color:var(--on-surface)">Urblaux Studio</h1>
        <p style="color:var(--on-surface-variant);font-size:14px;margin:8px 0 0">Constructor de webs, apps, juegos y más con IA</p>
      </div>
      <div id="auth-form">
        <div id="auth-login-form">
          <input class="auth-input" id="auth-email" type="email" placeholder="Email" autocomplete="email">
          <input class="auth-input" id="auth-password" type="password" placeholder="Contraseña" autocomplete="current-password">
          <button class="m3-btn m3-btn-filled" style="width:100%;height:48px;font-size:16px" onclick="App.login()">Iniciar Sesión</button>
          <p style="text-align:center;margin:16px 0 0;font-size:14px;color:var(--on-surface-variant)">
            ¿No tienes cuenta? <a href="#" style="color:var(--primary);text-decoration:none;font-weight:500" onclick="App.showRegister()">Regístrate</a>
          </p>
        </div>
        <div id="auth-register-form" style="display:none">
          <input class="auth-input" id="reg-username" type="text" placeholder="Nombre de usuario" autocomplete="username">
          <input class="auth-input" id="reg-email" type="email" placeholder="Email" autocomplete="email">
          <input class="auth-input" id="reg-name" type="text" placeholder="Nombre completo">
          <input class="auth-input" id="reg-password" type="password" placeholder="Contraseña" autocomplete="new-password">
          <button class="m3-btn m3-btn-filled" style="width:100%;height:48px;font-size:16px" onclick="App.register()">Crear Cuenta</button>
          <p style="text-align:center;margin:16px 0 0;font-size:14px;color:var(--on-surface-variant)">
            ¿Ya tienes cuenta? <a href="#" style="color:var(--primary);text-decoration:none;font-weight:500" onclick="App.showLogin()">Inicia Sesión</a>
          </p>
        </div>
      </div>
    </div>
  </div>`;
}

// ---- MESSAGE FORMATTING ----
function formatMessage(content) {
  if (!content) return '';
  try {
    if (typeof marked !== 'undefined' && marked.parse) {
      let html = marked.parse(content);
      return html;
    }
  } catch (e) {}
  return content.replace(/\n/g, '<br>').replace(/`([^`]+)`/g, '<code>$1</code>');
}

// ---- MAIN APP CONTROLLER ----
const App = {
  async init() {
    // Check for existing session
    const savedToken = localStorage.getItem('urblaux_token');
    const savedUser = localStorage.getItem('urblaux_user');
    if (savedToken && savedUser) {
      State.token = savedToken;
      try { State.user = JSON.parse(savedUser); } catch(e) {}
    }
    renderMainApp();
    if (State.user) {
      this.loadProjects();
      this.loadMemories();
    }
  },

  // --- Auth ---
  showRegister() {
    if ($('#auth-login-form')) $('#auth-login-form').style.display = 'none';
    if ($('#auth-register-form')) $('#auth-register-form').style.display = 'block';
  },
  showLogin() {
    if ($('#auth-login-form')) $('#auth-login-form').style.display = 'block';
    if ($('#auth-register-form')) $('#auth-register-form').style.display = 'none';
  },
  async login() {
    const email = $('#auth-email')?.value;
    const password = $('#auth-password')?.value;
    if (!email || !password) return this.toast('Completa todos los campos');
    const res = await API.post('/auth/login', { email, password });
    if (res.error) return this.toast(res.error);
    if (res.token) {
      State.token = res.token;
      State.user = res.user;
      localStorage.setItem('urblaux_token', res.token);
      localStorage.setItem('urblaux_user', JSON.stringify(res.user));
      renderMainApp();
      this.loadProjects();
      this.loadMemories();
    }
  },
  async register() {
    const username = $('#reg-username')?.value;
    const email = $('#reg-email')?.value;
    const name = $('#reg-name')?.value;
    const password = $('#reg-password')?.value;
    if (!username || !email || !password) return this.toast('Completa todos los campos');
    const res = await API.post('/auth/register', { username, email, display_name: name || username, password });
    if (res.error) return this.toast(res.error);
    if (res.token) {
      State.token = res.token;
      State.user = res.user;
      localStorage.setItem('urblaux_token', res.token);
      localStorage.setItem('urblaux_user', JSON.stringify(res.user));
      renderMainApp();
    }
  },
  logout() {
    State.user = null; State.token = null;
    localStorage.removeItem('urblaux_token');
    localStorage.removeItem('urblaux_user');
    renderMainApp();
  },

  // --- Navigation ---
  switchView(view) {
    State.currentView = view;
    $$('.view').forEach(v => v.classList.remove('active'));
    const target = $(`.view[data-view="${view}"]`);
    if (target) target.classList.add('active');
    $$('.nav-item').forEach(n => n.classList.remove('active'));
    const nav = $(`.nav-item[data-view="${view}"]`);
    if (nav) nav.classList.add('active');
  },
  goHome() { this.switchView('workspace'); },

  // --- Panels ---
  togglePanel(side) {
    State.panels[side] = !State.panels[side];
    const panel = $(`#panel-${side}`);
    if (panel) panel.style.display = State.panels[side] ? 'flex' : 'none';
  },

  // --- Chat ---
  async sendMessage(type) {
    const input = $(`#${type}-input`);
    if (!input || !input.value.trim()) return;
    const content = input.value.trim();
    input.value = '';
    
    // Add user message
    if (!State.messages[type]) State.messages[type] = [];
    State.messages[type].push({ role: 'user', content });
    this.appendMessage(type, 'user', content, '👤');
    
    // Show processing
    State.isProcessing = true;
    this.updateAgentBar();
    
    // Simulated agent response - in production this calls the multi-agent backend
    const thinkingId = this.showThinking(type);
    
    try {
      const res = await API.post('/chat/message', {
        project_id: State.currentProject?.id || 'default',
        chat_type: type,
        content: content,
      });
      
      this.removeThinking(thinkingId, type);
      
      if (res.response) {
        State.messages[type].push({ role: 'assistant', content: res.response, agent_icon: '⚡' });
        this.appendMessage(type, 'assistant', res.response, '⚡');
      } else if (res.error) {
        this.appendMessage(type, 'assistant', `Error: ${res.error}`, '⚠️');
      }

      // Show agent activity if available
      if (res.agent_activity) {
        State.agentActivity = res.agent_activity;
      }
    } catch (e) {
      this.removeThinking(thinkingId, type);
      this.appendMessage(type, 'assistant', 'Error de conexión. Intenta de nuevo.', '⚠️');
    }
    
    State.isProcessing = false;
    this.updateAgentBar();
  },

  appendMessage(type, role, content, icon) {
    const container = $(`#${type}-messages`);
    if (!container) return;
    const div = document.createElement('div');
    div.className = `msg ${role} m3-fade-up`;
    div.innerHTML = `
      <div class="msg-avatar">${role === 'user' ? '👤' : icon || '⚡'}</div>
      <div class="msg-bubble">${formatMessage(content)}</div>
    `;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
    // Highlight code blocks
    div.querySelectorAll('pre code').forEach(block => {
      if (typeof hljs !== 'undefined') hljs.highlightElement(block);
    });
  },

  showThinking(type) {
    const container = $(`#${type}-messages`);
    if (!container) return null;
    const id = 'thinking-' + Date.now();
    const div = document.createElement('div');
    div.id = id;
    div.className = 'msg assistant m3-fade-up';
    div.innerHTML = `
      <div class="msg-avatar">⚡</div>
      <div class="msg-bubble">
        <div style="display:flex;align-items:center;gap:8px">
          <div class="agent-thinking" style="width:100px;height:12px;border-radius:6px"></div>
          <span style="font-size:12px;color:var(--on-surface-variant)">Los agentes están trabajando...</span>
        </div>
      </div>
    `;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
    return id;
  },

  removeThinking(id, type) {
    if (id) { const el = $(`#${id}`); if (el) el.remove(); }
  },

  updateAgentBar() {
    const bar = $('#agent-bar');
    if (bar) bar.style.display = State.isProcessing ? 'flex' : 'none';
  },

  // --- Design Chat ---
  async sendDesignMsg() {
    const input = $('#design-input');
    if (!input || !input.value.trim()) return;
    const content = input.value.trim();
    input.value = '';
    this.appendDesignMsg('user', content, '👤');
    
    const thinkingId = this.showDesignThinking();
    
    const res = await API.post('/design/message', {
      project_id: State.currentProject?.id || 'default',
      content,
    });
    
    this.removeDesignThinking(thinkingId);
    
    if (res.response) {
      this.appendDesignMsg('assistant', res.response, '🎨');
    }
  },

  appendDesignMsg(role, content, icon) {
    const container = $('#design-messages');
    if (!container) return;
    const div = document.createElement('div');
    div.className = `msg ${role} m3-fade-up`;
    div.innerHTML = `<div class="msg-avatar">${icon}</div><div class="msg-bubble">${formatMessage(content)}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  },

  showDesignThinking() {
    const container = $('#design-messages');
    if (!container) return null;
    const id = 'dthink-' + Date.now();
    const div = document.createElement('div');
    div.id = id;
    div.className = 'msg assistant';
    div.innerHTML = `<div class="msg-avatar">🎨</div><div class="msg-bubble"><div class="agent-thinking" style="width:80px;height:10px;border-radius:5px"></div></div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
    return id;
  },
  removeDesignThinking(id) { if (id) { const el = $(`#${id}`); if (el) el.remove(); } },

  designQuick(type) {
    const prompts = {
      colors: 'Sugiere una paleta de colores moderna para mi proyecto',
      layout: 'Propón un layout responsive profesional',
      typo: 'Recomienda tipografías que funcionen bien para este proyecto',
      anim: 'Añade animaciones fluidas y modernas al proyecto',
    };
    const input = $('#design-input');
    if (input) { input.value = prompts[type] || ''; this.sendDesignMsg(); }
  },

  // --- Projects ---
  async loadProjects() {
    const res = await API.get('/projects');
    if (res.projects) State.projects = res.projects;
  },

  async newProject() {
    this.showDialog(`
      <h3 style="font-size:20px;margin:0 0 16px">✨ Nuevo Proyecto</h3>
      <input class="auth-input" id="np-name" placeholder="Nombre del proyecto">
      <textarea class="auth-input" id="np-desc" placeholder="Describe brevemente qué quieres crear..." style="min-height:80px;resize:vertical"></textarea>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
        <span class="m3-chip selected" data-type="web" onclick="App.selectProjectType(this,'web')">🌐 Web</span>
        <span class="m3-chip" data-type="app" onclick="App.selectProjectType(this,'app')">📱 App</span>
        <span class="m3-chip" data-type="game" onclick="App.selectProjectType(this,'game')">🎮 Juego</span>
        <span class="m3-chip" data-type="os" onclick="App.selectProjectType(this,'os')">💻 S.O.</span>
        <span class="m3-chip" data-type="ai" onclick="App.selectProjectType(this,'ai')">🤖 IA</span>
        <span class="m3-chip" data-type="ecommerce" onclick="App.selectProjectType(this,'ecommerce')">🛒 Tienda</span>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button class="m3-btn m3-btn-text" onclick="App.closeDialog()">Cancelar</button>
        <button class="m3-btn m3-btn-filled" onclick="App.createProject()">Crear</button>
      </div>
    `);
    this._newProjectType = 'web';
  },

  selectProjectType(el, type) {
    el.parentElement.querySelectorAll('.m3-chip').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    this._newProjectType = type;
  },

  async createProject() {
    const name = $('#np-name')?.value;
    const desc = $('#np-desc')?.value;
    if (!name) return this.toast('Pon un nombre al proyecto');
    const res = await API.post('/projects', { name, description: desc, type: this._newProjectType || 'web' });
    if (res.project) {
      State.currentProject = res.project;
      State.projects.push(res.project);
      this.closeDialog();
      renderMainApp();
      this.toast('Proyecto creado ✨');
    }
  },

  async openProject(id) {
    const res = await API.get(`/projects/${id}`);
    if (res.project) {
      State.currentProject = res.project;
      this.switchView('workspace');
      renderMainApp();
    }
  },

  // --- Sources ---
  async addSource() {
    this.showDialog(`
      <h3 style="font-size:20px;margin:0 0 16px">📚 Añadir Fuente</h3>
      <div style="display:flex;gap:8px;margin-bottom:16px">
        <span class="m3-chip selected" onclick="App.setSourceType(this,'url')">🔗 URL</span>
        <span class="m3-chip" onclick="App.setSourceType(this,'text')">📝 Texto</span>
        <span class="m3-chip" onclick="App.setSourceType(this,'file')">📄 Archivo</span>
      </div>
      <input class="auth-input" id="source-title" placeholder="Título (opcional)">
      <div id="source-url-input">
        <input class="auth-input" id="source-url" placeholder="https://...">
      </div>
      <div id="source-text-input" style="display:none">
        <textarea class="auth-input" id="source-text" placeholder="Pega el contenido aquí..." style="min-height:120px;resize:vertical"></textarea>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button class="m3-btn m3-btn-text" onclick="App.closeDialog()">Cancelar</button>
        <button class="m3-btn m3-btn-filled" onclick="App.saveSource()">Añadir</button>
      </div>
    `);
    this._sourceType = 'url';
  },

  setSourceType(el, type) {
    el.parentElement.querySelectorAll('.m3-chip').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    this._sourceType = type;
    if ($('#source-url-input')) $('#source-url-input').style.display = type === 'url' ? 'block' : 'none';
    if ($('#source-text-input')) $('#source-text-input').style.display = type === 'text' ? 'block' : 'none';
  },

  async saveSource() {
    const title = $('#source-title')?.value || '';
    const url = $('#source-url')?.value || '';
    const text = $('#source-text')?.value || '';
    const source = { title, type: this._sourceType, url, content: text, project_id: State.currentProject?.id };
    const res = await API.post('/sources', source);
    if (res.source) {
      State.sources.push(res.source);
      this.closeDialog();
      this.refreshSourcesPanel();
    }
  },

  addUrlSource() { this.addSource(); },
  addTextSource() { this.addSource(); setTimeout(() => this.setSourceType($('.m3-chip[data-type="text"]') || document.createElement('span'), 'text'), 100); },
  async searchSources() {
    this.toast('Buscando fuentes automáticamente...');
    const res = await API.post('/sources/auto-search', { project_id: State.currentProject?.id });
    if (res.sources) { State.sources.push(...res.sources); this.refreshSourcesPanel(); }
  },
  removeSource(id) { State.sources = State.sources.filter(s => s.id !== id); this.refreshSourcesPanel(); },
  refreshSourcesPanel() {
    const panel = $('#left-panel-content');
    if (panel) panel.innerHTML = renderSourcesPanel();
  },
  handleSourceDrop(e) {
    e.preventDefault();
    e.target.classList?.remove('dragover');
    this.toast('Archivo recibido - procesando...');
  },

  // --- Tabs ---
  switchLeftTab(tab) {
    const tabs = $$('.panel-left .m3-tab');
    tabs.forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
  },
  switchCenterTab(tab) {
    const tabs = $$('#center-tabs .m3-tab');
    tabs.forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    const content = $('#center-content');
    if (tab === 'chat') content.innerHTML = renderChatPanel('general');
    else if (tab === 'preview') {
      const defaultPreview = '<html><body style="display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;color:#666"><p>Preview will appear here</p></body></html>';
      content.innerHTML = '<div style="flex:1;padding:16px"><iframe class="preview-frame" id="preview-iframe"></iframe></div>';
      const iframe = document.getElementById('preview-iframe');
      if (iframe) iframe.setAttribute('srcdoc', State.previewCode || defaultPreview);
    }
    else if (tab === 'code') content.innerHTML = `<div style="flex:1;overflow:auto;padding:16px"><pre style="background:var(--surface-container-lowest);padding:16px;border-radius:12px;font-size:13px;white-space:pre-wrap"><code>${escapeHtml(State.previewCode || '// El código aparecerá aquí cuando crees tu proyecto')}</code></pre></div>`;
  },
  switchAutoTab(tab) {
    const tabs = $$('.view[data-view="automation"] .m3-tab');
    tabs.forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
  },

  // --- Automation ---
  async createAutomation() {
    this.showDialog(`
      <h3 style="font-size:20px;margin:0 0 16px">⚙️ Nueva Automatización</h3>
      <input class="auth-input" id="auto-name" placeholder="Nombre de la automatización">
      <textarea class="auth-input" id="auto-desc" placeholder="Describe qué quieres que haga automáticamente..." style="min-height:100px;resize:vertical"></textarea>
      <p style="font-size:13px;color:var(--on-surface-variant);margin:0 0 8px">Selecciona los agentes:</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
        ${Object.entries(AGENT_ROLES).map(([k,r]) => `<span class="m3-chip" onclick="this.classList.toggle('selected')" data-agent="${k}">${r.icon} ${r.name}</span>`).join('')}
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button class="m3-btn m3-btn-text" onclick="App.closeDialog()">Cancelar</button>
        <button class="m3-btn m3-btn-filled" onclick="App.saveAutomation()">Crear</button>
      </div>
    `);
  },

  async saveAutomation() {
    const name = $('#auto-name')?.value;
    const desc = $('#auto-desc')?.value;
    if (!name) return this.toast('Pon un nombre');
    const agents = [...$$('#dialog-content .m3-chip.selected')].map(c => c.dataset.agent);
    const res = await API.post('/automations', { name, description: desc, agents, project_id: State.currentProject?.id });
    if (res.automation) { this.closeDialog(); this.toast('Automatización creada'); }
  },

  selectAutomation(id) { this.toast(`Automatización seleccionada: ${id}`); },

  // --- Pomelli ---
  async pomelliAction(action) {
    this.toast(`Generando ${action}...`);
    const res = await API.post('/pomelli/generate', { action, project_id: State.currentProject?.id });
    if (res.result) this.toast('Contenido generado');
  },

  // --- Publish ---
  async publishTo(platform) {
    this.toast(`Publicando en ${platform}...`);
    const res = await API.post('/publish', { platform, project_id: State.currentProject?.id });
    if (res.url) { this.toast(`Publicado: ${res.url}`); window.open(res.url, '_blank'); }
  },

  // --- Memory ---
  async loadMemories() {
    const res = await API.get('/memory');
    if (res.memories) State.memories = res.memories;
  },
  async addMemory() {
    const content = prompt('Escribe algo que la IA deba recordar sobre ti:');
    if (content) {
      await API.post('/memory', { content });
      this.loadMemories();
    }
  },
  async deleteMemory(id) {
    await API.del(`/memory/${id}`);
    State.memories = State.memories.filter(m => m.id !== id);
  },

  // --- Urblaux Agent ---
  exportUrblaux() {
    this.showDialog(`
      <h3 style="font-size:20px;margin:0 0 16px">🔑 Exportar Urblaux Agent</h3>
      <p style="font-size:14px;color:var(--on-surface-variant);margin:0 0 16px">
        Exporta tu super-agente combinado como API key para usarlo en otros proyectos o plataformas.
      </p>
      <div style="padding:12px;background:var(--surface-container-highest);border-radius:12px;font-family:monospace;font-size:13px;word-break:break-all;margin-bottom:16px">
        urblaux_${State.user?.id || 'demo'}_${Date.now().toString(36)}
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button class="m3-btn m3-btn-text" onclick="App.closeDialog()">Cerrar</button>
        <button class="m3-btn m3-btn-filled" onclick="navigator.clipboard.writeText(this.previousElementSibling.previousElementSibling.textContent);App.toast('Copiado')">Copiar</button>
      </div>
    `);
  },

  // --- Quick Prompts ---
  quickPrompt(type) {
    const prompts = {
      web: 'Quiero crear una web moderna con ',
      app: 'Necesito una aplicación móvil que ',
      game: 'Quiero desarrollar un juego de ',
      os: 'Quiero construir un sistema operativo que ',
      ai: 'Necesito un motor de IA que ',
      ecommerce: 'Quiero una tienda online para vender ',
    };
    const input = $('#general-input');
    if (input) { input.value = prompts[type] || ''; input.focus(); }
  },

  // --- Profile ---
  showProfile() { this.switchView('settings'); },
  async saveProfile() {
    const name = $('#settings-name')?.value;
    const bio = $('#settings-bio')?.value;
    await API.put('/auth/profile', { display_name: name, bio });
    this.toast('Perfil guardado');
  },
  async saveSkills() {
    const skills = $('#custom-skills')?.value;
    await API.put('/auth/skills', { custom_skills: skills });
    this.toast('Skills guardadas');
  },
  setTheme(theme) {
    State.theme = theme;
    document.documentElement.dataset.theme = theme;
    renderMainApp();
  },

  // --- File Upload ---
  uploadFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = '*/*';
    input.onchange = (e) => { this.toast(`${e.target.files.length} archivo(s) subidos`); };
    input.click();
  },
  uploadDesignFile() { this.uploadFile(); },
  recordAudio() { this.toast('Grabación de audio iniciada...'); },
  searchWeb() { this.toast('Buscando en tiempo real...'); },

  // --- Config Agent ---
  configAgent(role) {
    const r = AGENT_ROLES[role];
    const providers = Object.entries(AI_PROVIDERS).filter(([k,p]) => p.roles.includes(role));
    this.showDialog(`
      <h3 style="font-size:20px;margin:0 0 4px">${r.icon} ${r.name}</h3>
      <p style="font-size:14px;color:var(--on-surface-variant);margin:0 0 16px">${r.desc}</p>
      <h4 style="font-size:14px;margin:0 0 8px">Modelos asignados (${providers.length} proveedores):</h4>
      <div style="display:grid;gap:8px;margin-bottom:16px">
        ${providers.map(([k,p]) => `
          <div style="padding:8px 12px;background:var(--surface-container-high);border-radius:12px;display:flex;align-items:center;gap:8px">
            <span>${p.icon}</span>
            <span style="font-weight:500;font-size:13px;flex:1">${p.name}</span>
            <span style="font-size:12px;color:var(--on-surface-variant)">${p.models.length} modelos</span>
          </div>
        `).join('')}
      </div>
      <button class="m3-btn m3-btn-text" onclick="App.closeDialog()">Cerrar</button>
    `);
  },

  // --- Dialogs ---
  showDialog(content) {
    const overlay = $('#dialog-overlay');
    const dialog = $('#dialog-content');
    if (dialog) dialog.innerHTML = content;
    if (overlay) overlay.classList.add('open');
  },
  closeDialog() {
    const overlay = $('#dialog-overlay');
    if (overlay) overlay.classList.remove('open');
  },

  // --- Toast ---
  toast(msg) {
    const existing = $('#toast-container');
    if (existing) existing.remove();
    const el = document.createElement('div');
    el.id = 'toast-container';
    el.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);padding:12px 24px;background:var(--inverse-surface);color:var(--inverse-on-surface);border-radius:12px;font-size:14px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,0.3);animation:m3FadeSlideUp 300ms ease';
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  },
};

// ---- HELPERS ----
function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function encodeHTMLAttr(str) {
  return str.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ---- EVENT LISTENERS ----
function initEventListeners() {
  // Close dialog on overlay click
  const overlay = $('#dialog-overlay');
  if (overlay) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) App.closeDialog();
    });
  }
  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') App.closeDialog();
    if (e.ctrlKey && e.key === 'k') { e.preventDefault(); $('#general-input')?.focus(); }
  });
}

// ---- INITIALIZE ----
document.addEventListener('DOMContentLoaded', () => App.init());
// Also try immediate init if DOM already loaded
if (document.readyState !== 'loading') App.init();
